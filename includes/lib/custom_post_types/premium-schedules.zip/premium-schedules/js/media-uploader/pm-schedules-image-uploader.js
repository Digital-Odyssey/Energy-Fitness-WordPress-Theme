(function($){

	$(document).ready(function(e) {
		
		//alert('pm-image-uploader loaded');
		
		if(wp.media !== undefined){
			
			var formfield = null;
		
			var clicked = '';
			
			var image_schedule_uploader;
			
			//Page header image
			$('#upload_image_button_sch').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (image_schedule_uploader) {
					 image_schedule_uploader.open();
					 return;
				 }
				
			});
					
			 //Extend the wp.media object
			 image_schedule_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 image_schedule_uploader.on('select', function() {
				attachment = image_schedule_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#img-uploader-field').val(url);
				$('.pm-admin-upload-field-preview').html('<img src="'+ url +'" />');
	
			 });
			 			
			
		}
		
		
		
		
	});

})(jQuery);