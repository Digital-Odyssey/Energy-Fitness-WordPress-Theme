<?php 

/*
Plugin Name: Premium Schedules for Energy WordPress Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying scheduled posts.
Version: 1.0
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

//Define global constants
if ( ! defined( 'PM_SCHEDULES_URL' ) ) {
	define( 'PM_SCHEDULES_URL', plugin_dir_url(__FILE__) );	
}
if ( ! defined( 'PM_SCHEDULES_PATH' ) ) {
	define( 'PM_SCHEDULES_PATH', plugin_dir_path(__FILE__) );
}
if ( ! defined( 'PM_SCHEDULES_ADMIN_URL' ) ) {
  define( 'PM_SCHEDULES_ADMIN_URL', PM_SCHEDULES_URL . 'admin');
}

/**** ACTIONS ****/
add_action('init', 'pm_ln_er_schedule_register');
add_action('admin_init', 'pm_ln_add_schedule_metaoptions');

/**** CRON *****/
add_action('init', 'pm_ln_schedules_cron');
add_action('pm_ln_schedules_cron_hook', 'pm_ln_check_expired_schedules');
add_filter('cron_schedules', 'pm_ln_two_minutes_schedules');

add_action('save_post', 'pm_ln_er_save_schedule');
add_action('admin_enqueue_scripts', 'pm_ln_load_schedule_admin_scripts');
add_action('wp_enqueue_scripts', 'pm_ln_load_schedule_front_scripts');
add_action("manage_posts_custom_column", "pm_ln_post_schedule_custom_columns");

/**** FILTERS *****/
//add_filter('template_include', 'pm_ln_re_set_template'); //Re-enable this line for third-party themes
add_filter ("manage_edit-post_schedules_columns", "pm_ln_post_schedule_edit_columns");

//Translation support
add_action('plugins_loaded', 'pm_ln_premium_schedules_load_textdomain');


/**** FUNCTIONS ****/
function pm_ln_premium_schedules_load_textdomain() { 
	load_plugin_textdomain( 'premiumschedules', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 


function pm_ln_schedules_cron() {

	$time = wp_next_scheduled('pm_ln_schedules_cron_hook');
	wp_unschedule_event($time, 'pm_ln_schedules_cron_hook');
	
	if( !wp_next_scheduled('pm_ln_schedules_cron_hook') ){
		wp_schedule_event(time(), 'hourly', 'pm_ln_schedules_cron_hook');
	}
	
}

function pm_ln_check_expired_schedules() {

	$type = 'post_schedules';
	$args = array(
	  'post_type' => $type,
	  'post_status' => 'publish'
	);
	
	$my_query = null;
	$my_query = new WP_Query($args);
	
	if( $my_query->have_posts() ) {
				
	    while ($my_query->have_posts()) : $my_query->the_post(); 
		
			$post_id = get_the_ID();
			$event_detail = get_post_custom($post_id);
			$endDate = $event_detail["re_end_date_event"][0];
			$today = date('Y-m-d');
			$reoc_event = $event_detail["reoc_event"][0];
		   	$re_until = $event_detail["re_until"][0];	   
		   
			if($reoc_event == 'once'){
								
				//program is not reocurring so we check the end date and compare to the current day
				if(strtotime($endDate) < strtotime($today)){
					update_post_meta($post_id, "is_expired", "true");
				}
				
				//$str = time();
				//wp_mail('leo@pulsarmedia.ca', 'Events expiry cron', "The following post id is $post_id.");
			} else {
			
				//program is reocurring so we check the until date and compare to the current day
				if(strtotime($re_until) < strtotime($today)){
					update_post_meta($post_id, "is_expired", "true");
				}
				
			}
			
		  
		endwhile;
	}
	
	
	
}

function pm_ln_two_minutes_schedules($schedules){
	
	$schedules['two-minutes'] = array(
		'interval' => 60,
		'display' => 'Every Two Minutes'
	);
	
	return $schedules;
		
}

function pm_ln_er_schedule_register() {
	
    $args = array(
        'label' => __('Schedule Entries', 'scheduleplugin'),
		'labels' => array(
			'add_new_item' => __( 'Add Schedule', 'premiumschedules' ), 
			'edit_item' => __( 'Edit Schedule', 'premiumschedules' ), 
			'view_item' => __( 'View Schedule', 'premiumschedules' ) ,
			'search_items' => __( 'Search Schedules', 'premiumschedules' )
			),
        'singular_label' => __('Schedule', 'scheduleplugin'),
        'public' => true,
		'show_in_menu' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'schedule'),
        'supports' => array('title', 'editor', 'author', 'excerpt', 'thumbnail'),
    );
 
    register_post_type( 'post_schedules' , $args );
}


function pm_ln_post_schedule_edit_columns($columns) {
 
	$columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => "Schedules",
		/*"pm_col_ev_cat" => "Category",
		"pm_col_ev_tags" => "Tags",*/
		"pm_col_schedule_start_date" => "Start Date/Time",
		"pm_col_schedule_end_date" => "End Date/Time",
		"pm_col_schedule_reoccurence" => "Reoccurence",
		"pm_col_schedule_location" => "Location / Studio Room",
		"pm_col_schedule_thumb" => "Featured Image",
		
		);
		
	return $columns;
	
}

function pm_ln_post_schedule_custom_columns($column) {
	
	global $post;
	$custom = get_post_custom();
	switch ($column) {
		

	/*case "pm_col_ev_cat":
		// - show taxonomy terms -
		$eventcats = get_the_terms($post->ID, "event_categoriess");
		$eventcats_html = array();
		if ($eventcats) {
		foreach ($eventcats as $eventcat)
		array_push($eventcats_html, $eventcat->name);
		echo implode($eventcats_html, ", ");
		} else {
		_e('None', 'themeforce');;
		}
	break;*/
	/*case "pm_col_ev_tags":
		// - show taxonomy terms -
		$eventtags = get_the_terms($post->ID, "eventtagss");
		$eventtags_html = array();
		if ($eventtags) {
		foreach ($eventtags as $eventtag)
		array_push($eventtags_html, $eventtag->name);
		echo implode($eventtags_html, ", ");
		} else {
		_e('None', 'themeforce');;
		}
	break;*/
	case "pm_col_schedule_start_date":
		// - show start date/time -
		$dt = get_post_meta($post->ID, 're_start_date_event', true );
			
		if($dt != ''){
			
			$todaysDate = date( 'Y-m-d' );
			$event_detail = get_post_custom($post->ID);
			$re_start_date_event = get_post_meta($post->ID, 're_start_date_event', true );
			$pm_reoc_event = get_post_meta(get_the_ID(), 'reoc_event', true);
			$is_expired = get_post_meta(get_the_ID(), 'is_expired', true);
			$pm_schedule_cancellation_meta = get_post_meta(get_the_ID(), 'pm_schedule_cancellation_meta', true);
			
			//echo $is_expired;
			
			if($is_expired === 'true'){
				
				echo 'Expired';
				
			} else {
				
				if($event_detail["allday_eve"][0] == '0'){
					echo pm_ln_formatScheduleDate($re_start_date_event)." <br />". get_post_meta($post->ID, 're_start_time', true );
				}else{
					echo pm_ln_formatScheduleDate($re_start_date_event) . ' <br />'.__('All Day Event', 'premiumschedules').'';
				}
				
			}
			
			if($pm_schedule_cancellation_meta === 'yes') {
				echo '<br /> ('.__('Program Cancelled', 'premiumschedules').')';
			}
			
			
		}
		
	break;
	case "pm_col_schedule_end_date":
	
		// - show end date/time -
		$dt = get_post_meta($post->ID, 're_end_date_event', true );
		
			
		if($dt != ''){
			
			$event_detail = get_post_custom($post->ID);
			$todaysDate = date( 'Y-m-d' );
			$re_end_date_event = get_post_meta($post->ID, 're_end_date_event', true );
			$re_end_time = get_post_meta($post->ID, 're_end_time', true );
			$pm_reoc_event = get_post_meta(get_the_ID(), 'reoc_event', true);
			$is_expired = get_post_meta(get_the_ID(), 'is_expired', true);
			$pm_schedule_cancellation_meta = get_post_meta(get_the_ID(), 'pm_schedule_cancellation_meta', true);
			
			if($is_expired === 'true'){
				
				echo 'Expired';
				
			} else {
				
				if($event_detail["allday_eve"][0] == '0'){
					echo pm_ln_formatScheduleDate($re_end_date_event)." <br />".$re_end_time;
				}else{
					echo pm_ln_formatScheduleDate($re_end_date_event) . ' <br />'.__('All Day Event', 'premiumschedules').'';
				}
				
			}
			
			if($pm_schedule_cancellation_meta === 'yes') {
				echo '<br /> ('.__('Program Cancelled', 'premiumschedules').')';
			}
			
			
		}
		
	break;
	
	case "pm_col_schedule_reoccurence":
		// - show reoccurence -
		echo pm_ln_getScheduleSummary(get_post_meta($post->ID, 're_start_date_event', true ),get_post_meta($post->ID, 're_until', true ),get_post_meta($post->ID, 'freq_event', true ),get_post_meta($post->ID, 'reoc_event', true ),get_post_meta($post->ID, 're_days', true ),get_post_meta($post->ID, 're_monthchoose', true ));
	break;
	
	case "pm_col_schedule_location":
		// - show times -
		$pm_schedule_location_meta = $custom["pm_schedule_location_meta"][0];
		
		echo $pm_schedule_location_meta;
		
	break;
	
	case "pm_col_schedule_thumb":
		// - show thumb -
		$post_image_id = get_post_thumbnail_id(get_the_ID());
		if ($post_image_id) {
			$thumbnail = wp_get_attachment_image_src( $post_image_id, 'post-thumbnail', false);
			if ($thumbnail) (string)$thumbnail = $thumbnail[0];
			
			echo '<img src="'.$thumbnail.'" alt="thumbnail" width="45%" height="45%" />';

		}
	break;
	
	
	
	 
	}
}

function pm_ln_load_schedule_front_scripts( ) {
	
	 wp_enqueue_script( 'event-main-front', PM_SCHEDULES_URL . 'js/front-end/premium-schedules.js', array('jquery'), '1.0', true );
	 wp_enqueue_style( 'event-styles-front', PM_SCHEDULES_URL . 'css/front-end/premium-schedules.css' );
	
}

function pm_ln_load_schedule_admin_scripts( $hook ) {
	
	$screen = get_current_screen();
		
	if ( is_admin() && $screen->post_type === "post_schedules" && $screen->base === "post" ) { 
		
		//CSS
		wp_enqueue_style( 'event-styles', PM_SCHEDULES_URL . 'css/style.css' );
		wp_enqueue_style( 'event-timepicker', PM_SCHEDULES_URL . 'js/timepicker/jquery.ptTimeSelect.css' );\
		wp_enqueue_style( 'event-jquery-ui-css', '//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css' );

		//JS
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-datepicker' );
		
		wp_enqueue_script( 'event-timepicker', PM_SCHEDULES_URL . 'js/timepicker/jquery.ptTimeSelect.js', array('jquery'), '1.0', true );
		wp_enqueue_script( 'event-main', PM_SCHEDULES_URL . 'js/main.js', array('jquery'), '1.0', true );
		
		wp_enqueue_script( 'event-media-uploader', PM_SCHEDULES_URL . 'js/media-uploader/pm-schedules-image-uploader.js', array('jquery'), '1.0', true );
		
		//JS Localization
		$js_main_file = PM_SCHEDULES_URL . '/js/premium-schedules.js';
		
		wp_register_script( 'schedulepluginText', $js_main_file );
		wp_enqueue_script( 'schedulepluginText' );
		$text_array = array( 
			'text1' => __('This program will repeat every', 'scheduleplugin'),
			'text2' => __('This program is running from', 'scheduleplugin'),
			'text3' => __('It is next occuring on', 'scheduleplugin'),
			'text4' => __('This program has ended', 'scheduleplugin'),
			'text5' => __('This program is running', 'scheduleplugin'),
			'text6' => __('month', 'scheduleplugin'),
			'text7' => __('on', 'scheduleplugin'),
			'text8' => __('until', 'scheduleplugin'),
			'text9' => __('year', 'scheduleplugin'),
			'text10' => __('every', 'scheduleplugin'),
			'text11' => __('every week', 'scheduleplugin'),
			'text12' => __('from', 'scheduleplugin'),
			'text13' => __('weeks', 'scheduleplugin'),
			'text14' => __('every', 'scheduleplugin'),
			'text15' => __('every month', 'scheduleplugin'),
			'text16' => __('months', 'scheduleplugin'),
			'text17' => __('once per year', 'scheduleplugin'),
			'text18' => __('years', 'scheduleplugin'),
			'text19' => __('day', 'scheduleplugin'),
			'text20' => __('week', 'scheduleplugin'),
			'text21' => __('days', 'scheduleplugin'),
		);
		wp_localize_script( 'schedulepluginText', 'schedulepluginTextObject', $text_array );
	
	}//end of if
	
}//end of load_scripts


/*function pm_ln_re_set_template($template){
		
	if(is_singular('post_schedules')){
		add_filter('the_content','pm_ln_er_single_event_content');
	}
	
	return $template;

}

function pm_ln_er_single_event_content($content){

	if( !is_singular('post_schedules') )
	return $content;
	
	//Check we are an event!
	if( get_post_type( get_the_ID() ) !== 'post_schedules' ){
		return $content;
	}


	include('templates/front_end_events.php');
	
	return $text;
	
}*/



function pm_ln_schedule_options(){
	include('templates/event_options.php');
}


function pm_ln_getScheduleSummary($firstDate,$until,$freq,$freq_st,$weekday,$weekdayChoose){
		
	if($freq > 1){
		$s = "s";// suffix
		$fre = $freq; // frequency
	}else{
		$s = "";
		$fre = "";
	}
	
	switch($freq_st){ 	
	
		case "daily":
			$st = __('This program will repeat every', 'scheduleplugin') . ' ' .$fre.' '.__('day', 'scheduleplugin').''.$s.' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($until);
		break;
		
		case "weekly":
			$st = __('This program will repeat every', 'scheduleplugin') . ' '.$fre.' '.__('week', 'scheduleplugin').''.$s.' '.__('on', 'scheduleplugin').' ' . $weekday . ' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($until);
		break;
		
		case "monthly":
		
		
			if($weekdayChoose=='byday'){
				$st = __('This program will repeat every', 'scheduleplugin') . ' '.$fre.' '.__('month', 'scheduleplugin').''.$s.' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($until);
			}
			
			if($weekdayChoose=='byweek'){
				
				$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
				$weekmonth = ["","First","Second","Third","Fourth","Fifth"];
				$fDate = date_create($firstDate);
				$week = date_format($fDate,'w');
				$day = date_format($fDate,'d');
				
				$tot = (int)($day / 7);
				$rem = $day % 7;
				
				if($rem != 0){
					$tot = $tot + 1;
				}
				
				$st = __('This program will repeat every', 'scheduleplugin') . ' '.$fre.' '.__('month', 'scheduleplugin').''.$s.' '.__('on', 'scheduleplugin').' '.$weekmonth[$tot].' '.$weekdays[$week].' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($until);
			
			}
		
		break;
		
		case "yearly":
		
			$st = __('This program will repeat every', 'scheduleplugin') . ' '.$fre.' '.__('year', 'scheduleplugin').''.$s.' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($until);
			
		break;
		
		default :
		
			$st = __('No reoccurance', 'scheduleplugin');
			
		break;
		
	}
	
	return $st; // status of reoccurance
	
}

function pm_ln_formatScheduleDate($date){
	
	$date=date_create($date);
	return date_format($date,"d M Y");
	
}

function pm_ln_formatScheduleDateTime($date_time){
	
	$date_time=date_create($date_time);
	return date_format($date_time,"d M Y h:i A");
	
}

/*** SCHEDULE META OPTIONS & FUNCTIONS *****/
function pm_ln_add_schedule_metaoptions() {
	
	//Header Image
	add_meta_box( 
		'pm_event_header_image_meta', //ID
		__('Page Header Image', 'scheduleplugin'),   //label
		'pm_ln_schedule_header_image_meta_function' , //function
		'post_schedules', //Post type
		'normal', 
		'high' 
	);
	
	//Event Details
	add_meta_box(
		"pm_schedule_info_meta", 
		__('Schedule Details', 'scheduleplugin'), 
		"pm_ln_schedule_options", 
		"post_schedules", 
		"normal", 
		"high"
	);
	
	//Location
	add_meta_box( 
		'pm_schedule_location_meta', //ID
		'Entry Location / Studio Room',  //label
		'pm_schedule_location_meta_function' , //function
		'post_schedules', //Post type
		'normal', 
		'high' 
	);
	
	add_meta_box( 
		'pm_schedule_cancellation_meta', //ID
		'Cancellation?',  //label
		'pm_schedule_cancellation_meta_function' , //function
		'post_schedules', //Post type
		'normal', 
		'high' 
	);

	//Disable Share options
	add_meta_box( 
		'pm_disable_share_feature', //ID
		__('Disable Share feature?', 'scheduleplugin'),  //label
		'pm_schedule_disable_share_feature_function' , //function
		'post_schedules', //Post type
		'normal', 
		'high' 
	);
	
}

function pm_ln_schedule_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_event_header_image_meta = get_post_meta( $post->ID, 'pm_event_header_image_meta', true );
	//echo $post->ID . $pm_event_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px', 'premiumschedules') ?></p>
		<input type="text" value="<?php echo esc_html($pm_event_header_image_meta); ?>" name="pm_event_header_image_meta" id="img-uploader-field" class="pm-admin-upload-field" />
		<input id="upload_image_button_sch" type="button" value="<?php _e('Media Library Image', 'premiumschedules'); ?>" class="button-secondary" />
        <div class="pm-admin-upload-field-preview"></div>
        
        <?php if($pm_event_header_image_meta) : ?>
        	<input id="remove_event_page_header_button" type="button" value="<?php _e('Remove Image', 'premiumschedules'); ?>" class="button-secondary" />
        <?php endif; ?>        
    
    <?php
	
}



function pm_schedule_disable_share_feature_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_disable_share_feature = get_post_meta( $post->ID, 'pm_disable_share_feature', true );
	//echo $pm_post_layout_meta;
	
	?>
        <select id="pm_disable_share_feature" name="pm_disable_share_feature" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_disable_share_feature, 'no' ); ?>><?php _e('No', 'premiumschedules') ?></option>
            <option value="yes" <?php selected( $pm_disable_share_feature, 'yes' ); ?>><?php _e('Yes', 'premiumschedules') ?></option>
        </select>
            
    <?php
	
}


function pm_schedule_location_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_schedule_location_meta = get_post_meta( $post->ID, 'pm_schedule_location_meta', true );
	//echo $pm_schedule_location_meta;

	//HTML code
	?>
		<input type="text" value="<?php echo esc_attr($pm_schedule_location_meta); ?>" name="pm_schedule_location_meta" class="pm-admin-text-field" />
        
    <?php
	
}


function pm_schedule_cancellation_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_schedule_cancellation_meta = get_post_meta( $post->ID, 'pm_schedule_cancellation_meta', true );
	//echo $pm_post_layout_meta;
	
	?>
        <select id="pm_schedule_cancellation_meta" name="pm_schedule_cancellation_meta" class="pm-admin-select-list">  
        	<option value="no" <?php selected( $pm_schedule_cancellation_meta, 'no' ); ?>><?php _e('NO', 'premiumschedules') ?></option>
            <option value="yes" <?php selected( $pm_schedule_cancellation_meta, 'yes' ); ?>><?php _e('YES', 'premiumschedules') ?></option>
        </select>
    
    <?php
	
}

//Save Data
function pm_ln_er_save_schedule(){
	
	if(isset($_POST['re_start_date_event'])){
		
		global $post;
		
		if(isset($_POST['pm_disable_share_feature'])){
			update_post_meta($post->ID, "pm_disable_share_feature", $_POST['pm_disable_share_feature']);
		}


		if(isset($_POST['pm_schedule_location_meta'])){
			update_post_meta($post->ID, "pm_schedule_location_meta", $_POST['pm_schedule_location_meta']);
		}


		if(isset($_POST['pm_schedule_cancellation_meta'])){
			update_post_meta($post->ID, "pm_schedule_cancellation_meta", $_POST['pm_schedule_cancellation_meta']);
		}
		
		update_post_meta($post->ID, "re_start_date_event", $_POST["re_start_date_event"]);
		
		update_post_meta($post->ID, "display_schedule_info", $_POST["display_schedule_info"]);
		
		if(!isset($_POST["allday_eve"])){
			update_post_meta($post->ID, "re_start_time", $_POST["re_start_time"]);
			update_post_meta($post->ID, "re_end_time", $_POST["re_end_time"]);
		}
		
		update_post_meta($post->ID, "re_end_date_event", $_POST["re_end_date_event"]);
				
		if(isset($_POST['allday_eve'])){
			update_post_meta($post->ID, "allday_eve", '1');
		} else {
			update_post_meta($post->ID, "allday_eve", '0');
		}
		
		update_post_meta($post->ID, "reoc_event", $_POST["reoc_event"]);
		update_post_meta($post->ID, "freq_event", $_POST["freq_event"]);
		
		if($_POST["reoc_event"] === 'once'){
		
			$today = date('Y-m-d');
		
			if(strtotime($_POST["re_end_date_event"]) < strtotime($today)){
				update_post_meta($post->ID, "is_expired", "true");
			} else {
				update_post_meta($post->ID, "is_expired", "false");
			}
			
		} else {
			
			$today = date('Y-m-d');
			
			if(strtotime($_POST["re_until"]) < strtotime($today)){
				update_post_meta($post->ID, "is_expired", "true");
			} else {
				update_post_meta($post->ID, "is_expired", "false");
			}
			
		}
		
		$days = "";
		if(isset($_POST['re_days'])){
			
			foreach($_POST['re_days'] as $day){
				$days .= $day . ",";
			}
			$days = substr($days,0,-1);
			
		} else {

			$days = 'Monday';
			
		}
		
		update_post_meta($post->ID, "re_days", $days);
		update_post_meta($post->ID, "re_monthchoose", $_POST["re_monthchoose"]);
		update_post_meta($post->ID, "re_until", $_POST["re_until"]);
		
		$upcomingDates = array();
		
		/*---------- Calculate Dates ------------*/
			$today = date('Y-m-d');
			
			if(strtotime($_POST["re_start_date_event"]) > strtotime($today)){
				$today=$_POST["re_start_date_event"];
			}
			
			$todayWeekDay=date('w',strtotime($today));
			
			$weekdaysNum=["Sunday" => 0 , "Monday" => 1, "Tuesday" => 2, "Wednesday" => 3, "Thursday" => 4, "Friday" => 5, "Saturday" => 6 ];
			$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
			
			if($_POST["reoc_event"] == 'once'){
				
			$message = "";
			
				if(!isset($_POST["allday_eve"])){
					
					$message1 = '<p>'.__('This program is running from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_end_date_event"])." ".$_POST["re_end_time"];
					
				} else {
					
					$message1 = '<p>'.__('This program is running from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"]) .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_end_date_event"]);
					
				}
			
			} else { 
				
			if(strtotime($_POST["re_until"])< strtotime($today)){
			
				$message = __('This program has ended', 'scheduleplugin');
				
				if(!isset($_POST["allday_eve"])){
					
					$message1 = '<p>'.__('This program is running from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_end_date_event"])." ".$_POST["re_end_time"];
					
				} else {
					
					$message1 = '<p>'.__('This program is running from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"]) .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_end_date_event"]);
					
				}
			
			
			} else {
			
				switch($_POST["reoc_event"]){
					
					case "daily":
					
					if(!isset($_POST["allday_eve"])){
						$message1 = '<p>'.__('This program is running from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_until"])." ".$_POST["re_end_time"];
					}else{
						$message1 = '<p>'.__('This program is running from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"]).' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_until"]);
					}
					
					$tomorrow = date('Y-m-d',strtotime($today . "+".$_POST["freq_event"]." days"));
					
					if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
						
						$message = "";
						
					} else {
						
						$message = __('It is next occuring on', 'scheduleplugin') . ' ';
					
						if(!isset($_POST["allday_eve"])){
							
							if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
								$message.=pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
							} else {
								$message.=pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"];
							}
						
						} else {
							
							if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
								$message.=pm_ln_formatScheduleDate($_POST["re_start_date_event"]);
							} else {
								$message.=pm_ln_formatScheduleDate($tomorrow);
							}
							
						}
						
						
					}
					
					break;
					
					case "weekly":
					
					$message1 = '<p>'.__('This program is running', 'scheduleplugin').'';
					
					if($_POST["freq_event"]!=1){
						$message1 .= ' '.__('every', 'scheduleplugin').' '.$_POST["freq_event"].' '.__('weeks', 'scheduleplugin').' ';
					}else{
						$message1 .= ' '.__('every week', 'scheduleplugin').' ';
					}
					
					if(!isset($_POST["allday_eve"])){
						$message1 .= ' '.__('from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_until"])." ".$_POST["re_end_time"];
					} else {
						$message1 .= ' '.__('from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"]).' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_until"]);
					}
					
					//$days = $_POST["re_days"];
					$defaultDay = array(0 => 'Monday');
					$days = !empty($_POST["re_days"]) ? $_POST["re_days"] : $defaultDay;
					$next = 0;
					$wd = $todayWeekDay;// Weekdays
					$nextDate = "0";
					
					while($next == 0){
						
						if(in_array($weekdays[$wd], $days)){
							
							$next = 1;
							
						} else {
							
							if($wd < 6){
								$wd++;
								$nextDate++;
							} else {
								$wd = 0;
								$nextDate = $nextDate + (($_POST["freq_event"] - 1) * 7) + 1;
							}
							
						}
					}
					
					$tomorrow = date('Y-m-d', strtotime($today . "+" . $nextDate . " days"));
					
					if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
						
						$message="";
						
					} else {
						
						$message = __('It is next occuring on', 'scheduleplugin') . ' ';
					
						if(!isset($_POST["allday_eve"])){
							
							if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
								$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
							}else{
								$message .= pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"];
							}
						
						}else{
							if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
								$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"]);
							}else{
								$message .= pm_ln_formatScheduleDate($tomorrow);
							}
						}
					}
					
					break;
					
					case "monthly":
					
						$message1 = '<p>'.__('This program is running', 'scheduleplugin').'';
						
						if($_POST["freq_event"]!=1){
							$message1 .= ' '.__('every', 'scheduleplugin').' '.$_POST["freq_event"].' '.__('months', 'scheduleplugin').' ';
						}else{
							$message1 .= ' '.__('every month', 'scheduleplugin').' ';
						}
						
						if(!isset($_POST["allday_eve"])){
						
							$message1 .= ' '.__('from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_until"])." ".$_POST["re_end_time"];
							
						 }else{
							 
							$message1 .= ' '.__('from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"]) .' '.__('until', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_until"]);
							
						 }
						if($_POST["re_monthchoose"] == 'byday') {
							
							$nextMonth = date('m', strtotime($today . "+" . $_POST["freq_event"]." months"));
							$nextMonthDate = date('d',strtotime($_POST["re_start_date_event"] . "+".$_POST["freq_event"]." months"));
							$nextMonthYear = date('Y',strtotime($today . "+".$_POST["freq_event"]." months"));
							$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$nextMonthDate));
							
							if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
								
								$message = "";
								
							} else {
								
								$message = __('It is next occuring on', 'scheduleplugin');
								
								if(!isset($_POST["allday_eve"])){
									
									if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
										$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
									}else{
										$message .= pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"];
									}
								
								} else {
									if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
										$message.=pm_ln_formatScheduleDate($_POST["re_start_date_event"]);
									}else{
										$message.=pm_ln_formatScheduleDate($tomorrow);
									}
								}
								
							}
						}
						
						if($_POST["re_monthchoose"] == 'byweek'){
						
							$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
							$weekmonth =["","First","Second","Third","Fourth","Fifth"];
							$fDate=date_create($_POST["re_start_date_event"]);
							$week=date_format($fDate,'w');
							$day= date_format($fDate,'d');
							
							$tot=(int)($day / 7);    // total week
							$rem=$day % 7;			// left days
							
							if($rem != 0){
								$tot = $tot + 1;
							}
							
							$nextMonth=date('m',strtotime($today . "+".$_POST["freq_event"]." months"));
							$nextMonthWeek=date('w',strtotime($today . "+".$_POST["freq_event"]." months"));
							$nextMonthDate=date('d',strtotime($today . "+".$_POST["freq_event"]." months"));
							$nextMonthYear=date('Y',strtotime($today . "+".$_POST["freq_event"]." months"));
																	
							switch($tot){
								
								case 1:
								
									$firstDayWeek = date('w', strtotime($nextMonthYear."-".$nextMonth."-1"));
									
									if($firstDayWeek > $week){
										$totalReqDays = (6 - $firstDayWeek) + ($week + 1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays+1;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								
								break;
								
								case 2:
								
									$firstDayWeek = date('w',strtotime($nextMonthYear."-".$nextMonth."-8"));
									if($firstDayWeek > $week){
										$totalReqDays = (6-$firstDayWeek) + ($week+1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays + 8;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									
								break;
								
								case 3:
								
									$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-15"));
									if($firstDayWeek > $week){
										$totalReqDays=(6 - $firstDayWeek) + ($week+1);
									} else {
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays+15;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									
								break;
								
								case 4:
								
									$firstDayWeek = date('w', strtotime($nextMonthYear."-".$nextMonth."-22"));
									if($firstDayWeek > $week){
										$totalReqDays = (6 - $firstDayWeek) + ($week+1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays + 22;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									
								break;
								
								case 5:
								
									$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-29"));
									
									if($firstDayWeek > $week){
										$totalReqDays = (6-$firstDayWeek) + ($week+1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth=$totalReqDays + 29;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									$tom = date('Y',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								
								break;
								
								
								
							}	
							
							if(strtotime($tomorrow) > strtotime($_POST["re_until"]) || (isset($tom) && $tom == '1970')){
								
								$message="";
								
							}else{
								
								$message = __('It is next occuring on','scheduleplugin') . ' ';
								
								if(!isset($_POST["allday_eve"])){
									
									if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
										$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
									}else{
										$message .= pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"];
									}
								
								} else {
									
									if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
										$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"]);
									}else{
										$message .= pm_ln_formatScheduleDate($tomorrow);
									}
									
								}
											
							}
									
									
								
						
						}
					
					break;
					
						case "yearly":
						
						$message1 = '<p>'.__('This program is running', 'scheduleplugin').'';
						
						if($_POST["freq_event"]!=1){
							$message1 .= ' '.__('every', 'scheduleplugin').' '.$_POST["freq_event"].' '.__('years', 'scheduleplugin').' ';
						}else{
							$message1 .= ' '.__('once per year', 'scheduleplugin').' ';
						}
						
						if(!isset($_POST["allday_eve"])){
							$message1 .= ' '.__('from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_until"])." ".$_POST["re_end_time"];
						}else{
							$message1 .= ' '.__('from', 'scheduleplugin').' '. pm_ln_formatScheduleDate($_POST["re_start_date_event"]).' '.__('until', 'scheduleplugin').' '.pm_ln_formatScheduleDate($_POST["re_until"]);
						}
						
						$year = date('Y',strtotime($_POST["re_start_date_event"]));
						$mon = date('m',strtotime($_POST["re_start_date_event"]));
						$da = date('d',strtotime($_POST["re_start_date_event"]));
						$currentDate = ($year + $_POST["freq_event"])."-".$mon."-".$da;
						$tomorrow = $currentDate;
						
						if(strtotime(($year+$_POST["freq_event"])."-".$mon."-".$da)> strtotime($_POST["re_until"])){
							$message = "";
						} else {
							
							$message = __('It is next occuring on', 'scheduleplugin');
							
							if(!isset($_POST["allday_eve"])){
								
								if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
									$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
								}else{
									$message .= pm_ln_formatScheduleDate(($year+$_POST["freq_event"])."-".$mon."-".$da)." ".$_POST["re_start_time"];
								}
							
							}else{
								if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
									$message .= pm_ln_formatScheduleDate($_POST["re_start_date_event"]);
								}else{
									$message .= pm_ln_formatScheduleDate(($year+$_POST["freq_event"])."-".$mon."-".$da);
								}
							}
							
						}
					
					break;			
					
				}
			}
			
			}
			
			update_post_meta($post->ID, "next_upcoming", $message);
			update_post_meta($post->ID, "event_duration", $message1);
			
			
			if($_POST["reoc_event"]!='once'){
			
			if(strtotime($_POST["re_until"])< strtotime($today)){
			
			
			} else {
				
				$occur = 1;// occurance frequency
				
				$nextDate = "0";
				
				$next = 0;
				$wd=$todayWeekDay;
					
				$currentDate=$today;
				
				if($_POST["reoc_event"]!='weekly'){
					if(!isset($_POST["allday_eve"])){
						$upcomingDates[] = pm_ln_formatScheduleDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"]." - ".$_POST["re_end_time"]; //ADD SPACE BETWEEN TIMES
						
						
					} else {
						$upcomingDates[] = pm_ln_formatScheduleDate($_POST["re_start_date_event"]);
					}
				}
				
				while(strtotime($_POST["re_until"])> strtotime($currentDate)){
			
				switch($_POST["reoc_event"]){
					
					case "daily":
					
						$tomorrow = date('Y-m-d',strtotime($today . "+".($_POST["freq_event"]*$occur)." days"));
						$currentDate = $tomorrow;
						
						if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
							
						} else {
							
							
							if(!isset($_POST["allday_eve"])){
								$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"]." - ".$_POST["re_end_time"];
								
								
							}else{
								$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow);
							}
							
							
						}
					
					break;
					
					case "weekly":
					
						$week = 1;
						$defaultDay = array(0 => 'Monday');
						//$days = $_POST["re_days"];
						$days = !empty($_POST["re_days"]) ? $_POST["re_days"] : $defaultDay;
						
						while( $wd < 7){
						
							if(in_array($weekdays[$wd],$days)){
								
								$next = 1;
								
									$tomorrow = date('Y-m-d',strtotime($today . "+".$nextDate." days"));
									
									$currentDate=$tomorrow;
									if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
										
									}else{
										
										
										if(!isset($_POST["allday_eve"])){
											$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"]." - ".$_POST["re_end_time"];
											
										}else{
											$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow);
										}
										
										
									}
									
							
								
							}
							
							if($wd==6){
							
							$nextDate=$nextDate+((($_POST["freq_event"])-1)*7);
							
							}
							
							$nextDate++;
							$wd++;
							
						}
						
						$wd=0;
					
					break;
					
					case "monthly" :
					
						if($_POST["re_monthchoose"]=='byday'){
						
							$nextMonth=date('m',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthDate=date('d',strtotime($_POST["re_start_date_event"] . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthYear=date('Y',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$nextMonthDate));
							$currentDate=$tomorrow;
							
							if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
								
							}else{
							
								
								if(!isset($_POST["allday_eve"])){
									$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"]."-".$_POST["re_end_time"];
									
									
								}else{
									$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow);
								}
								
								
								
							}
							
						}
						
						if($_POST["re_monthchoose"]=='byweek'){
						
							$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
							$weekmonth =["","First","Second","Third","Fourth","Fifth"];
							$fDate=date_create($_POST["re_start_date_event"]);
							$week=date_format($fDate,'w');
							$day= date_format($fDate,'d');
							
							$tot=(int)($day/7);
							$rem=$day%7;
							
							if($rem!=0){
								$tot=$tot+1;
							}
							
							$nextMonth=date('m',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthWeek=date('w',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthDate=date('d',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthYear=date('Y',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							
							switch($tot){
								case 1:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-1"));
								
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+1;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								
								break;
								case 2:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-8"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+8;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								case 3:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-15"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+15;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								case 4:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-22"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+22;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								case 5:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-29"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+29;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								$tom=date('Y',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								
								
								
							}	
							
							$currentDate=$tomorrow;
							if(strtotime($tomorrow)> strtotime($_POST["re_until"]) || (isset($tom) && $tom=='1970')){
								
							}else{
								
								
								if(!isset($_POST["allday_eve"])){
									$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow)." ".$_POST["re_start_time"]."-".$_POST["re_end_time"];
									
									
								}else{
									$upcomingDates[] = pm_ln_formatScheduleDate($tomorrow);
								}
								
								
							}
							
							
							//$tomorrow=date('Y-m-d',strtotime($today . "+".$_POST["freq_event"]." month"));
						
						}
					
					break;
					
					case "yearly":
					
						$year = date('Y',strtotime($_POST["re_start_date_event"]));
						$mon = date('m',strtotime($_POST["re_start_date_event"]));
						$da = date('d',strtotime($_POST["re_start_date_event"]));
						$currentDate = ($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da;
						$tomorrow = $currentDate;
						
						if(strtotime($tomorrow) > strtotime($_POST["re_until"])){
							
						} else {
						
						
										
							if(!isset($_POST["allday_eve"])){
								
								$tomorrow = ($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da;
								
								$upcomingDates[] = pm_ln_formatScheduleDate(($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da)." ".$_POST["re_start_time"]."-".$_POST["re_end_time"];
							
							}else{
								$tomorrow = ($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da;
								$upcomingDates[] = pm_ln_formatScheduleDate(($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da);
							}
							$currentDate=$tomorrow;						
						}
					
					break;			
					
				}
				
				$occur++;
				
				}
				
			}
			
			
			}
			
			$array_text = "";
			foreach($upcomingDates as $date){
				$array_text .= ''.$date.',';
			}
			$array_text = substr($array_text,0,-1);
			
			update_post_meta($post->ID, "upcoming_dates", $array_text);
			/*---------- Calculate Dates End ------------*/
			
			
	}
}


?>