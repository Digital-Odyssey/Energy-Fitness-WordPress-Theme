<?php 
		global $post;
        $event_detail = get_post_custom($post->ID);
		
		
		function pm_ln_getDays($freq, $freq_st){
		
			if($freq > 1){
			   $s  ="s";
			   $fre = $freq;
			}else{
			   $s = "";
			   $fre = "";
			}
			
			switch($freq_st){ 	
				case "daily":
					$st = 'day'.$s;
				break;
				case "weekly":
					$st = 'week'.$s;
				break;
				case "monthly":
					$st = 'month'.$s;
				break;
				case "yearly":
					$st = 'year'.$s;
				break;
			}
			
			return $st;
			
		}
		
		
        


?>
<div class="onetime" style="display:block;">
		

		<table id="eventorganiser_event_detail" class="form-table">
        
        		<tr valign="top" class="event-date">
					<td class="eo-label" style="width:200px;"><?php _e('Display schedule details?','eventplugin'); ?>: </td>
					<td> 

					<label>
                    
                        <select name="display_schedule_info" id="display_schedule_info">
                            <option value="yes" <?php if(isset($event_detail["display_schedule_info"][0]) && $event_detail["display_schedule_info"][0]=='yes'){echo "selected='selected'"; }?> ><?php _e('Yes','eventplugin'); ?></option>
                            <option value="no" <?php if(isset($event_detail["display_schedule_info"][0]) && $event_detail["display_schedule_info"][0]=='no'){echo "selected='selected'"; }?>><?php _e('No','eventplugin'); ?></option>
                        </select>
                        
                        <p style="font-size:12px; color:#666;"><i><?php _e('Choose whether or not to display the schedule details in the post.','eventplugin'); ?></i></p>
                    
                    </label>
					</td>
				</tr>
        
				<tr valign="top" class="event-date">
					<td class="eo-label" style="width:200px;"><?php _e('Start Date/Time','scheduleplugin'); ?>: </td>
					<td> 
						<input class="ui-widget-content ui-corner-all" readonly name="re_start_date_event" size="10" maxlength="10" id="from_date" value="<?php if(isset($event_detail["re_start_date_event"][0]) && $event_detail["re_start_date_event"][0]!=''){ echo $event_detail["re_start_date_event"][0]; }else{ echo date('Y-m-d'); }?>"/>
						
						<input readonly class="ui-widget-content ui-corner-all pm_time_eve" <?php if(isset($event_detail["allday_eve"][0]) && $event_detail["allday_eve"][0]=='1'){echo "disabled"; }?> name="re_start_time" size="10" maxlength="10" id="re_start_time"  value="<?php if(isset($event_detail["re_start_time"][0]) && $event_detail["re_start_time"][0]!=''){ echo $event_detail["re_start_time"][0]; }?>"/>
	

					</td>
				</tr>

				<tr valign="top" class="event-date">
					<td class="eo-label" style="width:200px;"><?php _e('End Date/Time','scheduleplugin'); ?>: </td>
					<td> 
						<input readonly class="ui-widget-content ui-corner-all" name="re_end_date_event" maxlength="10" id="to_date"   value="<?php if(isset($event_detail["re_end_date_event"][0]) && $event_detail["re_end_date_event"][0]!=''){ echo $event_detail["re_end_date_event"][0]; }else{echo date('Y-m-d'); }?>"/>
						<input readonly class="ui-widget-content ui-corner-all pm_time_eve" <?php if(isset($event_detail["allday_eve"][0]) && $event_detail["allday_eve"][0]=='1'){echo "disabled"; }?> name="re_end_time" size="10" maxlength="10" id="re_end_time"  value="<?php if(isset($event_detail["re_end_time"][0]) && $event_detail["re_end_time"][0]!=''){ echo $event_detail["re_end_time"][0]; }?>"/>
	


					<label>
					<input type="checkbox" id="allday_eve" <?php if(isset($event_detail["allday_eve"][0]) && $event_detail["allday_eve"][0]=='1'){echo "checked='checked'"; }?>   name="allday_eve"   value="1"/>
						<?php _e('All day','scheduleplugin'); ?>
                    </label>
					<div id="pm-events-maxdate-error-top"></div>
					</td>
				</tr>

				<tr class="event-date">
					<td class="eo-label" style="width:200px;"><?php _e('Reoccurence','scheduleplugin'); ?>: </td>
					<td> 
					
					<select name="reoc_event" id="reoc_event">
                        <option value="once" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='once'){echo "selected='selected'"; }?> ><?php _e('none','scheduleplugin'); ?></option>
                        <option value="daily" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='daily'){echo "selected='selected'"; }?>><?php _e('daily','scheduleplugin'); ?></option>
                        <option value="weekly" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='weekly'){echo "selected='selected'"; }?>><?php _e('weekly','scheduleplugin'); ?></option>
                        <option value="monthly" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='monthly'){echo "selected='selected'"; }?>><?php _e('monthly','scheduleplugin'); ?></option>
                        <option value="yearly" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='yearly'){echo "selected='selected'"; }?>><?php _e('yearly','scheduleplugin'); ?></option>
                    </select>
					</td>
				</tr>

				<tr valign="top"  class="event-date reocurrence_row" style=" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]!='once'){ ?>display:table-row;<?php }else{ echo "display:none;";}?>">
					<td></td>
					<td>
						<p><?php _e('Repeat every','scheduleplugin'); ?>
						<input  class="ui-widget-content ui-corner-all" name="freq_event" id="freq_event" type="number" min="1" max="365" maxlength="4" size="4" value="<?php if(isset($event_detail["freq_event"][0]) && $event_detail["freq_event"][0]!=''){ echo $event_detail["freq_event"][0]; }else{echo "1"; } ?>" /> 
						<span id="recpan" > <?php   if(isset($event_detail["freq_event"][0]) && isset($event_detail["reoc_event"][0])){echo pm_ln_getDays($event_detail["freq_event"][0],$event_detail["reoc_event"][0]); }?> </span>				
						</p>
						<?php 
						$days=array();
						if(isset($event_detail["re_days"][0])){
							$days = explode(",",$event_detail["re_days"][0]);
						}
						?>
						<p id="dayofweekrepeat" style=" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='weekly'){ ?>display:block;<?php }else{ echo "display:none;";}?>">
						<?php _e('on the following days','scheduleplugin'); ?>: <br /><br />
                        
                        <label for="day-Mon" > <?php _e('Mon','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Mon"  <?php if(in_array("Monday",$days)){echo "checked='checked'"; }?>  value="Monday" class="daysofweek" name="re_days[]"  />
                        <label for="day-Tue" > <?php _e('Tue','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Tue" <?php if(in_array("Tuesday",$days)){echo "checked='checked'"; }?>   value="Tuesday" class="daysofweek" name="re_days[]" />
                        <label for="day-Wed" > <?php _e('Wed','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Wed"  <?php if(in_array("Wednesday",$days)){echo "checked='checked'"; }?>  value="Wednesday" class="daysofweek" name="re_days[]"  />
                        <label for="day-Thu" > <?php _e('Thu','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Thu" <?php if(in_array("Thursday",$days)){echo "checked='checked'"; }?>    value="Thursday" class="daysofweek" name="re_days[]"  />
                        <label for="day-Fri" > <?php _e('Fri','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Fri" <?php if(in_array("Friday",$days)){echo "checked='checked'"; }?>   value="Friday" class="daysofweek" name="re_days[]" />
                        <label for="day-Sat" > <?php _e('Sat','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Sat" <?php if(in_array("Saturday",$days)){echo "checked='checked'"; }?>   value="Saturday" class="daysofweek" name="re_days[]" />
                        <label for="day-Sun" > <?php _e('Sun','scheduleplugin'); ?></label>
                        <input type="checkbox" id="day-Sun" <?php if(in_array("Sunday",$days)){echo "checked='checked'"; }?>   value="Sunday" class="daysofweek" name="re_days[]"  />
							
						</p>

						<p id="dayofmonthrepeat" style=" <?php if(isset($event_detail["reoc_event"][0]) && $event_detail["reoc_event"][0]=='monthly' ){ ?>display:block;<?php }else{ echo "display:none;";}?>">
						<label for="bymonthday" >	
							<input type="radio" id="bymonthday" class="monthchoose"  <?php if(isset($event_detail["re_monthchoose"][0]) && $event_detail["re_monthchoose"][0]=='byday'){echo "checked='checked'"; }?> checked="checked"  name="re_monthchoose"  value="byday" /> 
							<?php _e('day of month','scheduleplugin'); ?>
                        </label>
						<label for="byday" >
							<input type="radio" id="bydayweek" class="monthchoose"  name="re_monthchoose"  <?php if(isset($event_detail["re_monthchoose"][0]) && $event_detail["re_monthchoose"][0]=='byweek'){echo "checked='checked'"; }?> value="byweek" /> 
							<?php _e('day of week','scheduleplugin'); ?>
                        </label>
						</p>

						<p class="reoccurrence_label">
						 <?php _e('until','scheduleplugin'); ?>
						<input class="ui-widget-content ui-corner-all dates" name="re_until" id="until" size="10" maxlength="10"  value="<?php if(isset($event_detail["re_until"][0]) && $event_detail["re_until"][0]!=''){ echo $event_detail["re_until"][0]; }else{echo date('Y-m-d'); } ?>"/>
						</p>
                        <div id="pm-events-maxdate-error-bottom"></div>

						<p id="event_summary"> <?php if(isset($event_detail["re_start_date_event"][0]) && isset($event_detail["re_until"][0]) && isset($event_detail["freq_event"][0]) && isset($event_detail["re_days"][0]) && isset($event_detail["re_monthchoose"][0]) ){echo pm_ln_getScheduleSummary($event_detail["re_start_date_event"][0],$event_detail["re_until"][0],$event_detail["freq_event"][0],$event_detail["reoc_event"][0],$event_detail["re_days"][0],$event_detail["re_monthchoose"][0]); }?> </p>
					</td>
				</tr>
			</table>
		</div>