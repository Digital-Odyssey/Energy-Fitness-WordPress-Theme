<?php 
global $post;
$event_detail = get_post_custom($post->ID);

//print_r($event_detail);

$today = date('Y-m-d');

if(strtotime($event_detail["re_start_date_event"][0])> strtotime($today)){
	
	$today = $event_detail["re_start_date_event"][0];
	
}

$todayWeekDay = date('w',strtotime($today));
$weekdaysNum = ["Sunday" => 0 , "Monday" => 1, "Tuesday" => 2, "Wednesday" => 3, "Thursday" => 4, "Friday" => 5, "Saturday" => 6 ];
$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

$text = '';	

if ($event_detail["allday_eve"][0] == '0') {
	
	$text .= '<div class="pm-divider event"></div>';
	
	$text .= '<p class="pm-event-details-title" style="text-align:center;"><b>'.__('Event Details', 'scheduleplugin').'</b></p>';
} 

if ($event_detail["reoc_event"][0] != 'once'){

	$text .= '<div class="pm-event-details-info">' . $event_detail["event_duration"][0].'. '.$event_detail["next_upcoming"][0].'</div>';
	
	$text .= '<div class="pm-divider event"></div>';
	
	$text .= '<p class="pm-event-details-title" style="text-align:center;"><b>'.__('Upcoming Dates', 'scheduleplugin').'</b></p>';

	$year = date('Y',strtotime($event_detail["re_start_date_event"][0]));
	$mon = date('m',strtotime($event_detail["re_start_date_event"][0]));
	$da = date('d',strtotime($event_detail["re_start_date_event"][0]));
	$currentDate = ($year + $event_detail["freq_event"][0]) ."-". $mon ."-". $da;

	if(strtotime($event_detail["re_until"][0])< strtotime($today) || ($event_detail["reoc_event"][0] == 'yearly' && strtotime($event_detail["re_until"][0])< strtotime($currentDate))){
	
		$text .= '<p style="text-align:center;">'.__('No upcoming dates for this event', 'scheduleplugin').'</p>';
	
	} else {
	
		$upcoming_dates = explode(',',$event_detail["upcoming_dates"][0]);
		$text .= '<ul class="pm-event-upcoming-dates" id="pm-event-upcoming-dates">';
		
		foreach($upcoming_dates as $date){
			$text.='<li>'.$date.'</li>';
		}
		
		$text .= '</ul>';
		
		//echo count($upcoming_dates);
		
		if(count($upcoming_dates) > 5){
			$text .= '<br /><p style="text-align:center;"><a href="#" id="loadMore">'.__('Show more', 'scheduleplugin').'</a> &nbsp; <a href="#" id="showLess">'.__('Show less', 'scheduleplugin').'</a></p>';
		}
		
		
		
	}

} else {

	if ($event_detail["allday_eve"][0] == '0') {
		
		$text .= '<p style="text-align:center;">'.__('This scheduled event is running from', 'scheduleplugin').' '. pm_ln_formatDate($event_detail["re_start_date_event"][0])." ".$event_detail["re_start_time"][0] .' '.__('until', 'scheduleplugin').' '.pm_ln_formatDate($event_detail["re_end_date_event"][0])." ".$event_detail["re_end_time"][0].'</p>';
		
	} /*else {
		
		$text .= '<p style="text-align:center;">'.__('This event is running from', 'scheduleplugin').' '. pm_ln_formatDate($event_detail["re_start_date_event"][0]) .' '.__('until', 'scheduleplugin').' '.pm_ln_formatDate($event_detail["re_end_date_event"][0]).'</p>';
		
	}*/
}


?>