<?php 

/*
Plugin Name: Premium Events System for Energy WordPress Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying event items.
Version: 1.0
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

//Define global constants
if ( ! defined( 'PM_EVENTS_URL' ) ) {
	define( 'PM_EVENTS_URL', plugin_dir_url(__FILE__) );	
}
if ( ! defined( 'PM_EVENTS_PATH' ) ) {
	define( 'PM_EVENTS_PATH', plugin_dir_path(__FILE__) );
}
if ( ! defined( 'PM_EVENTS_ADMIN_URL' ) ) {
  define( 'PM_EVENTS_ADMIN_URL', PM_EVENTS_URL . 'admin');
}

/**** ACTIONS ****/
add_action('init', 'pm_ln_er_event_register');
add_action('init', 'pm_ln_er_event_category_register');
add_action('init', 'pm_ln_er_event_tag_register');
add_action('admin_init', 'pm_ln_add_event_metaoptions');

/**** CRON *****/
add_action('init', 'pm_ln_events_cron');
add_action('pm_ln_cron_hook', 'pm_ln_check_expired_events');
add_filter('cron_schedules', 'pm_ln_two_minutes');

add_action('save_post', 'pm_ln_er_save_event');
add_action('admin_enqueue_scripts', 'pm_ln_load_event_admin_scripts');
add_action('wp_enqueue_scripts', 'pm_ln_load_event_front_scripts');
add_action("manage_posts_custom_column", "pm_ln_post_event_custom_columns");

/**** FILTERS *****/
//add_filter('template_include', 'pm_ln_re_set_template'); //Re-enable this line for third-party themes
add_filter ("manage_edit-post_event_columns", "pm_ln_post_event_edit_columns");

//Translation support
add_action('plugins_loaded', 'pm_ln_premium_events_load_textdomain');


/**** FUNCTIONS ****/
function pm_ln_premium_events_load_textdomain() { 
	load_plugin_textdomain( 'premiumevents', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 


function pm_ln_events_cron() {

	$time = wp_next_scheduled('pm_ln_cron_hook');
	wp_unschedule_event($time, 'pm_ln_cron_hook');
	
	if( !wp_next_scheduled('pm_ln_cron_hook') ){
		wp_schedule_event(time(), 'hourly', 'pm_ln_cron_hook');
	}
	
}

function pm_ln_check_expired_events() {

	$type = 'post_event';
	$args = array(
	  'post_type' => $type,
	  'post_status' => 'publish'
	);
	
	$my_query = null;
	$my_query = new WP_Query($args);
	
	if( $my_query->have_posts() ) {
				
	    while ($my_query->have_posts()) : $my_query->the_post(); 
		
			$post_id = get_the_ID();
			$event_detail = get_post_custom($post_id);
			$endDate = $event_detail["re_end_date_event"][0];
			$today = date('Y-m-d');
			$reoc_event = $event_detail["reoc_event"][0];
			$re_until = $event_detail["re_until"][0];	   
		   
			if($reoc_event == 'once'){
								
				//program is not reocurring so we check the end date and compare to the current day
				if(strtotime($endDate) < strtotime($today)){
					update_post_meta($post_id, "is_expired", "true");
				}
				
				//$str = time();
				//wp_mail('leo@pulsarmedia.ca', 'Events expiry cron', "The following post id is $post_id.");
				
			} else {
			
				//program is reocurring so we check the until date and compare to the current day
				if(strtotime($re_until) < strtotime($today)){
					update_post_meta($post_id, "is_expired", "true");
				}
				
			}
			
		  
		endwhile;
	}
	
	
	
}

function pm_ln_two_minutes($schedules){
	
	$schedules['two-minutes'] = array(
		'interval' => 60,
		'display' => 'Every Two Minutes'
	);
	
	return $schedules;
		
}

function pm_ln_er_event_register() {
	
    $args = array(
        'label' => __('Events', 'eventplugin'),
		'labels' => array(
			'add_new_item' => __( 'Add Event', 'premiumevents' ), 
			'edit_item' => __( 'Edit Event', 'premiumevents' ), 
			'view_item' => __( 'View Event', 'premiumevents' ) ,
			'search_items' => __( 'Search Events', 'premiumevents' )
			),
        'singular_label' => __('Event', 'eventplugin'),
        'public' => true,
		'show_in_menu' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'events'),
        'supports' => array('title', 'editor', 'author', 'excerpt', 'thumbnail'),
    );
 
    register_post_type( 'post_event' , $args );
}

function pm_ln_er_event_category_register() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Event Categories', 'premiumevents' ),
		'singular_name' => __( 'Event Categories', 'premiumevents' ),
		'search_items' =>  __( 'Search Event Categories', 'premiumevents' ),
		'popular_items' => __( 'Popular Event Categories', 'premiumevents' ),
		'all_items' => __( 'All Event Categories', 'premiumevents' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Event Category', 'premiumevents' ),
		'update_item' => __( 'Update Event Category', 'premiumevents' ),
		'add_new_item' => __( 'Add Event Category', 'premiumevents' ),
		'new_item_name' => __( 'New Event Category', 'premiumevents' ),
		'separate_items_with_commas' => __( 'Separate Event Categories with commas', 'premiumevents' ),
		'add_or_remove_items' => __( 'Add or remove Event Categories', 'premiumevents' ),
		'choose_from_most_used' => __( 'Choose from the most used Event Categories', 'premiumevents' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'event_categoriess', 'post_event', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'event-category' ), // changes name in permalink structure
    ));
	
	//flush_rewrite_rules();	
}

function pm_ln_er_event_tag_register() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Event Tags', 'premiumevents' ),
		'singular_name' => __( 'Event Tags', 'premiumevents' ),
		'search_items' =>  __( 'Search Event Tags', 'premiumevents' ),
		'popular_items' => __( 'Popular Event Tags', 'premiumevents' ),
		'all_items' => __( 'All Event Tags', 'premiumevents' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Event Tag', 'premiumevents' ),
		'update_item' => __( 'Update Event Tag', 'premiumevents' ),
		'add_new_item' => __( 'Add Event Tag', 'premiumevents' ),
		'new_item_name' => __( 'New Event Tag', 'premiumevents' ),
		'separate_items_with_commas' => __( 'Separate Event Tags with commas', 'premiumevents' ),
		'add_or_remove_items' => __( 'Add or remove Event Tags', 'premiumevents' ),
		'choose_from_most_used' => __( 'Choose from the most used Event Tags', 'premiumevents' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'eventtagss', 'post_event', array(
		'hierarchical' => false, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'event-tag' ), // changes name in permalink structure
    ));
	
	//flush_rewrite_rules();	
}

function pm_ln_post_event_edit_columns($columns) {
 
	$columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => "Event",
		"pm_col_ev_cat" => "Category",
		"pm_col_ev_tags" => "Tags",
		"pm_col_ev_start_date" => "Start Date/Time",
		"pm_col_ev_end_date" => "End Date/Time",
		"pm_col_ev_reoccurence" => "Reoccurence",
		"pm_col_ev_thumb" => "Event Image",
		
		);
	return $columns;
	
}

function pm_ln_post_event_custom_columns($column) {
	
	global $post;
	$custom = get_post_custom();
	switch ($column) {
		

	case "pm_col_ev_cat":
		// - show taxonomy terms -
		$eventcats = get_the_terms($post->ID, "event_categoriess");
		$eventcats_html = array();
		if ($eventcats) {
		foreach ($eventcats as $eventcat)
		array_push($eventcats_html, $eventcat->name);
		echo implode($eventcats_html, ", ");
		} else {
		_e('None', 'themeforce');;
		}
	break;
	case "pm_col_ev_tags":
		// - show taxonomy terms -
		$eventtags = get_the_terms($post->ID, "eventtagss");
		$eventtags_html = array();
		if ($eventtags) {
		foreach ($eventtags as $eventtag)
		array_push($eventtags_html, $eventtag->name);
		echo implode($eventtags_html, ", ");
		} else {
		_e('None', 'themeforce');;
		}
	break;
	case "pm_col_ev_start_date":
		// - show start date/time -
		$dt = get_post_meta($post->ID, 're_start_date_event', true );
			
		if($dt != ''){
			
			$todaysDate = date( 'Y-m-d' );
			$event_detail = get_post_custom($post->ID);
			$re_start_date_event = get_post_meta($post->ID, 're_start_date_event', true );
			$pm_reoc_event = get_post_meta(get_the_ID(), 'reoc_event', true);
			$is_expired = get_post_meta(get_the_ID(), 'is_expired', true);
			
			//echo $is_expired;
			
			if($is_expired === 'true'){
				
				echo 'Expired';
				
			} else {
				
				if($event_detail["allday_eve"][0] == '0'){
					echo pm_ln_formatDate($re_start_date_event)." <br />". get_post_meta($post->ID, 're_start_time', true );
				}else{
					echo pm_ln_formatDate($re_start_date_event) . ' <br />(All Day Event)';
				}
				
			}
			
			
		}
		
	break;
	case "pm_col_ev_end_date":
	
		// - show end date/time -
		$dt = get_post_meta($post->ID, 're_end_date_event', true );
		
			
		if($dt != ''){
			
			$event_detail = get_post_custom($post->ID);
			$todaysDate = date( 'Y-m-d' );
			$re_end_date_event = get_post_meta($post->ID, 're_end_date_event', true );
			$re_end_time = get_post_meta($post->ID, 're_end_time', true );
			$pm_reoc_event = get_post_meta(get_the_ID(), 'reoc_event', true);
			$is_expired = get_post_meta(get_the_ID(), 'is_expired', true);
			
			if($is_expired === 'true'){
				
				echo 'Expired';
				
			} else {
				
				if($event_detail["allday_eve"][0] == '0'){
					echo pm_ln_formatDate($re_end_date_event)." <br />".$re_end_time;
				}else{
					echo pm_ln_formatDate($re_end_date_event) . ' <br />(All Day Event)';
				}
				
			}
			
			
		}
	break;
	
	case "pm_col_ev_reoccurence":
		// - show reoccurence -
		echo pm_ln_getEventSummary(get_post_meta($post->ID, 're_start_date_event', true ),get_post_meta($post->ID, 're_until', true ),get_post_meta($post->ID, 'freq_event', true ),get_post_meta($post->ID, 'reoc_event', true ),get_post_meta($post->ID, 're_days', true ),get_post_meta($post->ID, 're_monthchoose', true ));
	break;
	case "pm_col_ev_thumb":
		// - show thumb -
		$post_image_id = get_post_thumbnail_id(get_the_ID());
		if ($post_image_id) {
			$thumbnail = wp_get_attachment_image_src( $post_image_id, 'post-thumbnail', false);
			if ($thumbnail) (string)$thumbnail = $thumbnail[0];
			
			echo '<img src="'.$thumbnail.'" alt="thumbnail" width="45%" height="45%" />';

		}
	break;
	 
	}
}

function pm_ln_load_event_front_scripts( ) {
	
	 wp_enqueue_script( 'event-main-front', PM_EVENTS_URL . 'js/front-end/premium-events.js', array('jquery'), '1.0', true );
	 wp_enqueue_style( 'event-styles-front', PM_EVENTS_URL . 'css/front-end/premium-events.css' );
	
}

function pm_ln_load_event_admin_scripts( $hook ) {
	
	$screen = get_current_screen();
		
	if ( is_admin() && $screen->post_type === "post_event" && $screen->base === "post" ) { 
		
		//CSS
		wp_enqueue_style( 'event-styles', PM_EVENTS_URL . 'css/style.css' );
		wp_enqueue_style( 'event-timepicker', PM_EVENTS_URL . 'js/timepicker/jquery.ptTimeSelect.css' );\
		wp_enqueue_style( 'event-jquery-ui-css', '//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css' );

		//JS
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-datepicker' );
		
		wp_enqueue_script( 'event-timepicker', PM_EVENTS_URL . 'js/timepicker/jquery.ptTimeSelect.js', array('jquery'), '1.0', true );
		wp_enqueue_script( 'event-main', PM_EVENTS_URL . 'js/main.js', array('jquery'), '1.0', true );
		
		wp_enqueue_script( 'event-media-uploader', PM_EVENTS_URL . 'js/media-uploader/pm-events-image-uploader.js', array('jquery'), '1.0', true );
		
		//JS Localization
		$js_main_file = PM_EVENTS_URL . '/js/premium-events.js';
		
		wp_register_script( 'eventPluginText', $js_main_file );
		wp_enqueue_script( 'eventPluginText' );
		$text_array = array( 
			'text1' => __('This event will repeat every', 'eventplugin'),
			'text2' => __('This event is running from', 'eventplugin'),
			'text3' => __('It is next occuring on', 'eventplugin'),
			'text4' => __('This event has ended', 'eventplugin'),
			'text5' => __('This event is running', 'eventplugin'),
			'text6' => __('month', 'eventplugin'),
			'text7' => __('on', 'eventplugin'),
			'text8' => __('until', 'eventplugin'),
			'text9' => __('year', 'eventplugin'),
			'text10' => __('every', 'eventplugin'),
			'text11' => __('every week', 'eventplugin'),
			'text12' => __('from', 'eventplugin'),
			'text13' => __('weeks', 'eventplugin'),
			'text14' => __('every', 'eventplugin'),
			'text15' => __('every month', 'eventplugin'),
			'text16' => __('months', 'eventplugin'),
			'text17' => __('once per year', 'eventplugin'),
			'text18' => __('years', 'eventplugin'),
			'text19' => __('day', 'eventplugin'),
			'text20' => __('week', 'eventplugin'),
			'text21' => __('days', 'eventplugin'),
		);
		wp_localize_script( 'eventPluginText', 'eventPluginTextObject', $text_array );
	
	}//end of if
	
}//end of load_scripts


function pm_ln_re_set_template($template){
		
	if(is_singular('post_event')){
		add_filter('the_content','pm_ln_er_single_event_content');
	}
	
	return $template;

}

function pm_ln_er_single_event_content($content){

	if( !is_singular('post_event') )
	return $content;
	
	//Check we are an event!
	if( get_post_type( get_the_ID() ) !== 'post_event' ){
		return $content;
	}


	include('templates/front_end_events.php');
	
	return $text;
	
}



function pm_ln_event_options(){
	include('templates/event_options.php');
}


function pm_ln_getEventSummary($firstDate,$until,$freq,$freq_st,$weekday,$weekdayChoose){
		
	if($freq > 1){
		$s = "s";// suffix
		$fre = $freq; // frequency
	}else{
		$s = "";
		$fre = "";
	}
	
	switch($freq_st){ 	
	
		case "daily":
			$st = __('This event will repeat every', 'eventplugin') . ' ' .$fre.' '.__('day', 'eventplugin').''.$s.' '.__('until', 'eventplugin').' '.pm_ln_formatDate($until);
		break;
		
		case "weekly":
			$st = __('This event will repeat every', 'eventplugin') . ' '.$fre.' '.__('week', 'eventplugin').''.$s.' '.__('on', 'eventplugin').' ' . $weekday . ' '.__('until', 'eventplugin').' '.pm_ln_formatDate($until);
		break;
		
		case "monthly":
		
		
			if($weekdayChoose=='byday'){
				$st = __('This event will repeat every', 'eventplugin') . ' '.$fre.' '.__('month', 'eventplugin').''.$s.' '.__('until', 'eventplugin').' '.pm_ln_formatDate($until);
			}
			
			if($weekdayChoose=='byweek'){
				
				$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
				$weekmonth = ["","First","Second","Third","Fourth","Fifth"];
				$fDate = date_create($firstDate);
				$week = date_format($fDate,'w');
				$day = date_format($fDate,'d');
				
				$tot = (int)($day / 7);
				$rem = $day % 7;
				
				if($rem != 0){
					$tot = $tot + 1;
				}
				
				$st = __('This event will repeat every', 'eventplugin') . ' '.$fre.' '.__('month', 'eventplugin').''.$s.' '.__('on', 'eventplugin').' '.$weekmonth[$tot].' '.$weekdays[$week].' '.__('until', 'eventplugin').' '.pm_ln_formatDate($until);
			
			}
		
		break;
		
		case "yearly":
		
			$st = __('This event will repeat every', 'eventplugin') . ' '.$fre.' '.__('year', 'eventplugin').''.$s.' '.__('until', 'eventplugin').' '.pm_ln_formatDate($until);
			
		break;
		
		default :
		
			$st = __('No reoccurance', 'eventplugin');
			
		break;
		
	}
	
	return $st; // status of reoccurance
	
}

function pm_ln_formatDate($date){
	
	$date=date_create($date);
	return date_format($date,"d M Y");
	
}

function pm_ln_formatDateTime($date_time){
	
	$date_time=date_create($date_time);
	return date_format($date_time,"d M Y h:i A");
	
}

/*** EVENTS META OPTIONS & FUNCTIONS *****/
function pm_ln_add_event_metaoptions() {
	
	//Header Image
	add_meta_box( 
		'pm_event_header_image_meta', //ID
		__('Page Header Image', 'eventplugin'),   //label
		'pm_ln_event_header_image_meta_function' , //function
		'post_event', //Post type
		'normal', 
		'high' 
	);
	
	//Event Details
	add_meta_box(
		"eventInfo-meta", 
		__('Event Details', 'eventplugin'), 
		"pm_ln_event_options", 
		"post_event", 
		"normal", 
		"high"
	);
	
	//Event Fan Page
	add_meta_box( 
		'pm_event_fan_page_meta', //ID
		__('Event Fan Page URL', 'eventplugin'),  //label
		'pm_ln_event_fan_page_meta_function' , //function
		'post_event', //Post type
		'normal', 
		'high' 
	);
	
	//Disable Share options
	add_meta_box( 
		'pm_disable_share_feature', //ID
		__('Disable Share feature?', 'eventplugin'),  //label
		'pm_event_disable_share_feature_function' , //function
		'post_event', //Post type
		'normal', 
		'high' 
	);
	
}

function pm_ln_event_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_event_header_image_meta = get_post_meta( $post->ID, 'pm_event_header_image_meta', true );
	//echo $post->ID . $pm_event_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px', 'premiumevents') ?></p>
		<input type="text" value="<?php echo esc_html($pm_event_header_image_meta); ?>" name="pm_event_header_image_meta" id="img-uploader-field" class="pm-admin-upload-field" />
		<input id="upload_event_image_button" type="button" value="<?php _e('Media Library Image', 'premiumevents'); ?>" class="button-secondary" />
        <div class="pm-admin-upload-field-preview"></div>
        
        <?php if($pm_event_header_image_meta) : ?>
        	<input id="remove_event_page_header_button" type="button" value="<?php _e('Remove Image', 'premiumevents'); ?>" class="button-secondary" />
        <?php endif; ?>        
    
    <?php
	
}

function pm_ln_event_fan_page_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_event_fan_page_meta = get_post_meta( $post->ID, 'pm_event_fan_page_meta', true );
	//echo $pm_event_fan_page_meta;
		

	//HTML code
	?>
    	<p><?php _e('Enter a Facebook fan page URL','premiumevents'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_event_fan_page_meta); ?>" name="pm_event_fan_page_meta" class="pm-admin-text-field" />
    <?php
}

function pm_event_disable_share_feature_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_disable_share_feature = get_post_meta( $post->ID, 'pm_disable_share_feature', true );
	//echo $pm_post_layout_meta;
	
	?>
        <select id="pm_disable_share_feature" name="pm_disable_share_feature" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_disable_share_feature, 'no' ); ?>><?php _e('No', 'premiumevents') ?></option>
            <option value="yes" <?php selected( $pm_disable_share_feature, 'yes' ); ?>><?php _e('Yes', 'premiumevents') ?></option>
        </select>
            
    <?php
	
}


//Save Data
function pm_ln_er_save_event(){
	
	if(isset($_POST['re_start_date_event'])){
		
		global $post;
		
		if(isset($_POST['pm_disable_share_feature'])){
			update_post_meta($post->ID, "pm_disable_share_feature", $_POST['pm_disable_share_feature']);
		}


		if(isset($_POST['pm_event_fan_page_meta'])){
			update_post_meta($post->ID, "pm_event_fan_page_meta", $_POST['pm_event_fan_page_meta']);
		}


		if(isset($_POST['pm_event_header_image_meta'])){
			update_post_meta($post->ID, "pm_event_header_image_meta", $_POST['pm_event_header_image_meta']);
		}
		
		update_post_meta($post->ID, "re_start_date_event", $_POST["re_start_date_event"]);
		
		update_post_meta($post->ID, "display_event_info", $_POST["display_event_info"]);
		
		if(!isset($_POST["allday_eve"])){
			update_post_meta($post->ID, "re_start_time", $_POST["re_start_time"]);
			update_post_meta($post->ID, "re_end_time", $_POST["re_end_time"]);
		}
		
		update_post_meta($post->ID, "re_end_date_event", $_POST["re_end_date_event"]);
				
		if(isset($_POST['allday_eve'])){
			update_post_meta($post->ID, "allday_eve", '1');
		} else {
			update_post_meta($post->ID, "allday_eve", '0');
		}
		
		update_post_meta($post->ID, "reoc_event", $_POST["reoc_event"]);
		update_post_meta($post->ID, "freq_event", $_POST["freq_event"]);
		
		if($_POST["reoc_event"] === 'once'){
		
			$today = date('Y-m-d');
		
			if(strtotime($_POST["re_end_date_event"]) < strtotime($today)){
				update_post_meta($post->ID, "is_expired", "true");
			} else {
				update_post_meta($post->ID, "is_expired", "false");
			}
			
		} else {
			
			$today = date('Y-m-d');
			
			if(strtotime($_POST["re_until"]) < strtotime($today)){
				update_post_meta($post->ID, "is_expired", "true");
			} else {
				update_post_meta($post->ID, "is_expired", "false");
			}
			
		}
		
		$days = "";
		if(isset($_POST['re_days'])){
			
			foreach($_POST['re_days'] as $day){
				$days .= $day . ",";
			}
			$days = substr($days,0,-1);
			
		} else {

			$days = 'Monday';
			
		}
		
		update_post_meta($post->ID, "re_days", $days);
		update_post_meta($post->ID, "re_monthchoose", $_POST["re_monthchoose"]);
		update_post_meta($post->ID, "re_until", $_POST["re_until"]);
		
		$upcomingDates = array();
		
		/*---------- Calculate Dates ------------*/
			$today = date('Y-m-d');
			
			if(strtotime($_POST["re_start_date_event"]) > strtotime($today)){
				$today=$_POST["re_start_date_event"];
			}
			
			$todayWeekDay=date('w',strtotime($today));
			
			$weekdaysNum=["Sunday" => 0 , "Monday" => 1, "Tuesday" => 2, "Wednesday" => 3, "Thursday" => 4, "Friday" => 5, "Saturday" => 6 ];
			$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
			
			if($_POST["reoc_event"] == 'once'){
				
			$message = "";
			
				if(!isset($_POST["allday_eve"])){
					
					$message1 = '<p>'.__('This event is running from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_end_date_event"])." ".$_POST["re_end_time"];
					
				} else {
					
					$message1 = '<p>'.__('This event is running from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"]) .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_end_date_event"]);
					
				}
			
			} else { 
				
			if(strtotime($_POST["re_until"])< strtotime($today)){
			
				$message = __('This event has ended', 'eventplugin');
				
				if(!isset($_POST["allday_eve"])){
					
					$message1 = '<p>'.__('This event is running from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_end_date_event"])." ".$_POST["re_end_time"];
					
				} else {
					
					$message1 = '<p>'.__('This event is running from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"]) .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_end_date_event"]);
					
				}
			
			
			} else {
			
				switch($_POST["reoc_event"]){
					
					case "daily":
					
					if(!isset($_POST["allday_eve"])){
						$message1 = '<p>'.__('This event is running from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_until"])." ".$_POST["re_end_time"];
					}else{
						$message1 = '<p>'.__('This event is running from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"]).' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_until"]);
					}
					
					$tomorrow = date('Y-m-d',strtotime($today . "+".$_POST["freq_event"]." days"));
					
					if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
						
						$message = "";
						
					} else {
						
						$message = __('It is next occuring on', 'eventplugin') . ' ';
					
						if(!isset($_POST["allday_eve"])){
							
							if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
								$message.=pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
							} else {
								$message.=pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"];
							}
						
						} else {
							
							if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
								$message.=pm_ln_formatDate($_POST["re_start_date_event"]);
							} else {
								$message.=pm_ln_formatDate($tomorrow);
							}
							
						}
						
						
					}
					
					break;
					
					case "weekly":
					
					$message1 = '<p>'.__('This event is running', 'eventplugin').'';
					
					if($_POST["freq_event"]!=1){
						$message1 .= ' '.__('every', 'eventplugin').' '.$_POST["freq_event"].' '.__('weeks', 'eventplugin').' ';
					}else{
						$message1 .= ' '.__('every week', 'eventplugin').' ';
					}
					
					if(!isset($_POST["allday_eve"])){
						$message1 .= ' '.__('from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_until"])." ".$_POST["re_end_time"];
					} else {
						$message1 .= ' '.__('from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"]).' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_until"]);
					}
					
					//$days = $_POST["re_days"];
					$defaultDay = array(0 => 'Monday');
					$days = !empty($_POST["re_days"]) ? $_POST["re_days"] : $defaultDay;
					$next = 0;
					$wd = $todayWeekDay;// Weekdays
					$nextDate = "0";
					
					while($next == 0){
						
						if(in_array($weekdays[$wd], $days)){
							
							$next = 1;
							
						} else {
							
							if($wd < 6){
								$wd++;
								$nextDate++;
							} else {
								$wd = 0;
								$nextDate = $nextDate + (($_POST["freq_event"] - 1) * 7) + 1;
							}
							
						}
					}
					
					$tomorrow = date('Y-m-d', strtotime($today . "+" . $nextDate . " days"));
					
					if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
						
						$message="";
						
					} else {
						
						$message = __('It is next occuring on', 'eventplugin') . ' ';
					
						if(!isset($_POST["allday_eve"])){
							
							if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
								$message .= pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
							}else{
								$message .= pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"];
							}
						
						}else{
							if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
								$message .= pm_ln_formatDate($_POST["re_start_date_event"]);
							}else{
								$message .= pm_ln_formatDate($tomorrow);
							}
						}
					}
					
					break;
					
					case "monthly":
					
						$message1 = '<p>'.__('This event is running', 'eventplugin').'';
						
						if($_POST["freq_event"]!=1){
							$message1 .= ' '.__('every', 'eventplugin').' '.$_POST["freq_event"].' '.__('months', 'eventplugin').' ';
						}else{
							$message1 .= ' '.__('every month', 'eventplugin').' ';
						}
						
						if(!isset($_POST["allday_eve"])){
						
							$message1 .= ' '.__('from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'eventplugin').' '. pm_ln_formatDate($_POST["re_until"])." ".$_POST["re_end_time"];
							
						 }else{
							 
							$message1 .= ' '.__('from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"]) .' '.__('until', 'eventplugin').' '. pm_ln_formatDate($_POST["re_until"]);
							
						 }
						if($_POST["re_monthchoose"] == 'byday') {
							
							$nextMonth = date('m', strtotime($today . "+" . $_POST["freq_event"]." months"));
							$nextMonthDate = date('d',strtotime($_POST["re_start_date_event"] . "+".$_POST["freq_event"]." months"));
							$nextMonthYear = date('Y',strtotime($today . "+".$_POST["freq_event"]." months"));
							$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$nextMonthDate));
							
							if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
								
								$message = "";
								
							} else {
								
								$message = __('It is next occuring on', 'eventplugin');
								
								if(!isset($_POST["allday_eve"])){
									
									if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
										$message .= pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
									}else{
										$message .= pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"];
									}
								
								} else {
									if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
										$message.=pm_ln_formatDate($_POST["re_start_date_event"]);
									}else{
										$message.=pm_ln_formatDate($tomorrow);
									}
								}
								
							}
						}
						
						if($_POST["re_monthchoose"] == 'byweek'){
						
							$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
							$weekmonth =["","First","Second","Third","Fourth","Fifth"];
							$fDate=date_create($_POST["re_start_date_event"]);
							$week=date_format($fDate,'w');
							$day= date_format($fDate,'d');
							
							$tot=(int)($day / 7);    // total week
							$rem=$day % 7;			// left days
							
							if($rem != 0){
								$tot = $tot + 1;
							}
							
							$nextMonth=date('m',strtotime($today . "+".$_POST["freq_event"]." months"));
							$nextMonthWeek=date('w',strtotime($today . "+".$_POST["freq_event"]." months"));
							$nextMonthDate=date('d',strtotime($today . "+".$_POST["freq_event"]." months"));
							$nextMonthYear=date('Y',strtotime($today . "+".$_POST["freq_event"]." months"));
																	
							switch($tot){
								
								case 1:
								
									$firstDayWeek = date('w', strtotime($nextMonthYear."-".$nextMonth."-1"));
									
									if($firstDayWeek > $week){
										$totalReqDays = (6 - $firstDayWeek) + ($week + 1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays+1;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								
								break;
								
								case 2:
								
									$firstDayWeek = date('w',strtotime($nextMonthYear."-".$nextMonth."-8"));
									if($firstDayWeek > $week){
										$totalReqDays = (6-$firstDayWeek) + ($week+1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays + 8;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									
								break;
								
								case 3:
								
									$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-15"));
									if($firstDayWeek > $week){
										$totalReqDays=(6 - $firstDayWeek) + ($week+1);
									} else {
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays+15;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									
								break;
								
								case 4:
								
									$firstDayWeek = date('w', strtotime($nextMonthYear."-".$nextMonth."-22"));
									if($firstDayWeek > $week){
										$totalReqDays = (6 - $firstDayWeek) + ($week+1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth = $totalReqDays + 22;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									
								break;
								
								case 5:
								
									$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-29"));
									
									if($firstDayWeek > $week){
										$totalReqDays = (6-$firstDayWeek) + ($week+1);
									}else{
										$totalReqDays = $week - $firstDayWeek;
									}
									$dateNextMonth=$totalReqDays + 29;
									$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
									$tom = date('Y',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								
								break;
								
								
								
							}	
							
							if(strtotime($tomorrow) > strtotime($_POST["re_until"]) || (isset($tom) && $tom == '1970')){
								
								$message="";
								
							}else{
								
								$message = __('It is next occuring on','eventplugin') . ' ';
								
								if(!isset($_POST["allday_eve"])){
									
									if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
										$message .= pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
									}else{
										$message .= pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"];
									}
								
								} else {
									
									if(strtotime($_POST["re_start_date_event"]) > strtotime(date('Y-m-d'))){
										$message .= pm_ln_formatDate($_POST["re_start_date_event"]);
									}else{
										$message .= pm_ln_formatDate($tomorrow);
									}
									
								}
											
							}
									
									
								
						
						}
					
					break;
					
						case "yearly":
						
						$message1='<p>'.__('This event is running', 'eventplugin').'';
						
						if($_POST["freq_event"]!=1){
							$message1 .= ' '.__('every', 'eventplugin').' '.$_POST["freq_event"].' '.__('years', 'eventplugin').' ';
						}else{
							$message1 .= ' '.__('once per year', 'eventplugin').' ';
						}
						
						if(!isset($_POST["allday_eve"])){
							$message1 .= ' '.__('from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"] .' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_until"])." ".$_POST["re_end_time"];
						}else{
							$message1 .= ' '.__('from', 'eventplugin').' '. pm_ln_formatDate($_POST["re_start_date_event"]).' '.__('until', 'eventplugin').' '.pm_ln_formatDate($_POST["re_until"]);
						}
						
						$year = date('Y',strtotime($_POST["re_start_date_event"]));
						$mon = date('m',strtotime($_POST["re_start_date_event"]));
						$da = date('d',strtotime($_POST["re_start_date_event"]));
						$currentDate = ($year + $_POST["freq_event"])."-".$mon."-".$da;
						$tomorrow = $currentDate;
						
						if(strtotime(($year+$_POST["freq_event"])."-".$mon."-".$da)> strtotime($_POST["re_until"])){
							$message = "";
						} else {
							
							$message = __('It is next occuring on', 'eventplugin');
							
							if(!isset($_POST["allday_eve"])){
								
								if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
									$message .= pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"];
								}else{
									$message .= pm_ln_formatDate(($year+$_POST["freq_event"])."-".$mon."-".$da)." ".$_POST["re_start_time"];
								}
							
							}else{
								if(strtotime($_POST["re_start_date_event"])> strtotime(date('Y-m-d'))){
									$message .= pm_ln_formatDate($_POST["re_start_date_event"]);
								}else{
									$message .= pm_ln_formatDate(($year+$_POST["freq_event"])."-".$mon."-".$da);
								}
							}
							
						}
					
					break;			
					
				}
			}
			
			}
			
			update_post_meta($post->ID, "next_upcoming", $message);
			update_post_meta($post->ID, "event_duration", $message1);
			
			
			if($_POST["reoc_event"]!='once'){
			
			if(strtotime($_POST["re_until"])< strtotime($today)){
			
			
			} else {
				
				$occur = 1;// occurance frequency
				
				$nextDate = "0";
				
				$next = 0;
				$wd=$todayWeekDay;
					
				$currentDate=$today;
				
				if($_POST["reoc_event"]!='weekly'){
					if(!isset($_POST["allday_eve"])){
						$upcomingDates[] = pm_ln_formatDate($_POST["re_start_date_event"])." ".$_POST["re_start_time"]." - ".$_POST["re_end_time"]; //ADD SPACE BETWEEN TIMES
						
						
					} else {
						$upcomingDates[] = pm_ln_formatDate($_POST["re_start_date_event"]);
					}
				}
				
				while(strtotime($_POST["re_until"])> strtotime($currentDate)){
			
				switch($_POST["reoc_event"]){
					
					case "daily":
					
						$tomorrow = date('Y-m-d',strtotime($today . "+".($_POST["freq_event"]*$occur)." days"));
						$currentDate = $tomorrow;
						
						if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
							
						} else {
							
							
							if(!isset($_POST["allday_eve"])){
								$upcomingDates[] = pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"]." - ".$_POST["re_end_time"];
								
								
							}else{
								$upcomingDates[] = pm_ln_formatDate($tomorrow);
							}
							
							
						}
					
					break;
					
					case "weekly":
					
						$week = 1;
						$defaultDay = array(0 => 'Monday');
						//$days = $_POST["re_days"];
						$days = !empty($_POST["re_days"]) ? $_POST["re_days"] : $defaultDay;
						
						while( $wd < 7){
						
							if(in_array($weekdays[$wd],$days)){
								
								$next = 1;
								
									$tomorrow = date('Y-m-d',strtotime($today . "+".$nextDate." days"));
									
									$currentDate=$tomorrow;
									if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
										
									}else{
										
										
										if(!isset($_POST["allday_eve"])){
											$upcomingDates[] = pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"]." - ".$_POST["re_end_time"];
											
										}else{
											$upcomingDates[] = pm_ln_formatDate($tomorrow);
										}
										
										
									}
									
							
								
							}
							
							if($wd==6){
							
							$nextDate=$nextDate+((($_POST["freq_event"])-1)*7);
							
							}
							
							$nextDate++;
							$wd++;
							
						}
						
						$wd=0;
					
					break;
					
					case "monthly" :
					
						if($_POST["re_monthchoose"]=='byday'){
						
							$nextMonth=date('m',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthDate=date('d',strtotime($_POST["re_start_date_event"] . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthYear=date('Y',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$nextMonthDate));
							$currentDate=$tomorrow;
							
							if(strtotime($tomorrow)> strtotime($_POST["re_until"])){
								
							}else{
							
								
								if(!isset($_POST["allday_eve"])){
									$upcomingDates[] = pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"]."-".$_POST["re_end_time"];
									
									
								}else{
									$upcomingDates[] = pm_ln_formatDate($tomorrow);
								}
								
								
								
							}
							
						}
						
						if($_POST["re_monthchoose"]=='byweek'){
						
							$weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
							$weekmonth =["","First","Second","Third","Fourth","Fifth"];
							$fDate=date_create($_POST["re_start_date_event"]);
							$week=date_format($fDate,'w');
							$day= date_format($fDate,'d');
							
							$tot=(int)($day/7);
							$rem=$day%7;
							
							if($rem!=0){
								$tot=$tot+1;
							}
							
							$nextMonth=date('m',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthWeek=date('w',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthDate=date('d',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							$nextMonthYear=date('Y',strtotime($today . "+".($_POST["freq_event"]*$occur)." months"));
							
							switch($tot){
								case 1:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-1"));
								
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+1;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								
								break;
								case 2:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-8"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+8;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								case 3:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-15"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+15;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								case 4:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-22"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+22;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								case 5:
								$firstDayWeek=date('w',strtotime($nextMonthYear."-".$nextMonth."-29"));
								if($firstDayWeek>$week){
								$totalReqDays=(6-$firstDayWeek)+($week+1);
								}else{
								$totalReqDays=$week-$firstDayWeek;
								}
								$dateNextMonth=$totalReqDays+29;
								$tomorrow = date('Y-m-d',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								$tom=date('Y',strtotime($nextMonthYear."-".$nextMonth."-".$dateNextMonth));
								break;
								
								
								
							}	
							
							$currentDate=$tomorrow;
							if(strtotime($tomorrow)> strtotime($_POST["re_until"]) || (isset($tom) && $tom=='1970')){
								
							}else{
								
								
								if(!isset($_POST["allday_eve"])){
									$upcomingDates[] = pm_ln_formatDate($tomorrow)." ".$_POST["re_start_time"]."-".$_POST["re_end_time"];
									
									
								}else{
									$upcomingDates[] = pm_ln_formatDate($tomorrow);
								}
								
								
							}
							
							
							//$tomorrow=date('Y-m-d',strtotime($today . "+".$_POST["freq_event"]." month"));
						
						}
					
					break;
					
					case "yearly":
					
						$year = date('Y',strtotime($_POST["re_start_date_event"]));
						$mon = date('m',strtotime($_POST["re_start_date_event"]));
						$da = date('d',strtotime($_POST["re_start_date_event"]));
						$currentDate = ($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da;
						$tomorrow = $currentDate;
						
						if(strtotime($tomorrow) > strtotime($_POST["re_until"])){
							
						} else {
						
						
										
							if(!isset($_POST["allday_eve"])){
								
								$tomorrow = ($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da;
								
								$upcomingDates[] = pm_ln_formatDate(($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da)." ".$_POST["re_start_time"]."-".$_POST["re_end_time"];
							
							}else{
								$tomorrow = ($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da;
								$upcomingDates[] = pm_ln_formatDate(($year+($_POST["freq_event"]*$occur))."-".$mon."-".$da);
							}
							$currentDate=$tomorrow;						
						}
					
					break;			
					
				}
				
				$occur++;
				
				}
				
			}
			
			
			}
			
			$array_text = "";
			foreach($upcomingDates as $date){
				$array_text .= ''.$date.',';
			}
			$array_text = substr($array_text,0,-1);
			
			update_post_meta($post->ID, "upcoming_dates", $array_text);
			/*---------- Calculate Dates End ------------*/
			
			
	}
}


?>