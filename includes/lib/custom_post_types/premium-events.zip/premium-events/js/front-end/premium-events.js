(function($) {
	
	$(document).ready(function(){
				
		//Upcoming dates expander
		var list_size = $("#pm-event-upcoming-dates li").size();
		var x = 5,
		items_to_show = 5;
		$('#pm-event-upcoming-dates li:lt('+x+')').show();
		
		$('#showLess').hide();
		
		
		$('#loadMore').click(function (e) {
			
			e.preventDefault();
			
			x = ( x + 5 <= list_size) ? x + 5 : list_size;
			
			//if we've reached the end hide show more button
			if(x >= list_size) {
				$(this).hide();
			} 
			
			if(x > items_to_show){
				$('#showLess').show();
			}
			
			console.log(x);
			
			$('#pm-event-upcoming-dates li:lt('+x+')').show();
		});
		
		$('#showLess').click(function (e) {
			
			e.preventDefault();
									
			x = ( x - 5 < items_to_show ) ? items_to_show : x - 5;
			
			//if we've reached the top hide show less button
			if (x <= items_to_show) {
				$(this).hide();	
			}
			
			if(x < list_size){
				$('#loadMore').show();
			}
			
			console.log(x);
			
			$('#pm-event-upcoming-dates li').not(':lt('+x+')').hide();
		});
	
	});
	
})(jQuery);