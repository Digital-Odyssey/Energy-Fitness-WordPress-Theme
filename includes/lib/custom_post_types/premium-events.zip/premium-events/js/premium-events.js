(function($) {
	
	$(document).ready(function(){
				
		//Header image preview
		if( $('.pm-admin-upload-field').length > 0 ){
	
			var value = $('.pm-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-field-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Remove page header button
		if( $('#remove_event_page_header_button').length > 0 ){
	
			$('#remove_event_page_header_button').click(function(e) {
								
				$('#img-uploader-field').val('');
				$('.pm-admin-upload-field-preview').empty();
				
			});
	
		}
				
		$('.pm_time_eve').ptTimeSelect();
	
		$('.dates').datepicker({
			'dateFormat':'yy-mm-dd',
			
			onSelect: function(selected){
				  
				  var dt = new Date(selected);
				  var $startDate = $('#from_date').val();
				  
				  if( (dt >= new Date($startDate).getTime())) {
				
						$('#pm-events-maxdate-error-bottom').hide();
						
				  } else if( (dt < new Date($startDate).getTime()) ) {
							
						$('#pm-events-maxdate-error-bottom').show();
						$('#pm-events-maxdate-error-bottom').html('<b>Warning:</b> your start date is greater than your reoccurence end date. This can cause unexpected results.');
							
				  } else {
						//nothing	
				  }
				  
			 }
			
		});
		
		$('#freq_event,#until').change(function(){
		
			if($('#freq_event').val()>1){
				var s = "s";
				var fre=$('#freq_event').val(); 
			}else{
				var s = "";
				var fre = "";
			}
			
			
			switch($('#reoc_event').val()){
				
				case "daily":
				
					$('#recpan').html('day'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','none');
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text19+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				
				break;
				
				case "weekly":
				
					$('#recpan').html('week'+s);
					$('#dayofweekrepeat').css('display','block');
					$('#dayofmonthrepeat').css('display','none');
					var days = "";
					$('.daysofweek').each(function(){
					
						if($(this).is(':checked')){
							days+=" "+$(this).val()+",";
						}
					
					});
					
					days = days.slice(0,-1);
					
					if(days == ''){
						$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text20+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
					}else{
						$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text20+''+s+' '+eventPluginTextObject.text7+' '+days+' '+eventPluginTextObject.text8+' '+$('#until').val());
					}
					
				break;
				
				case "monthly":
				
					$('#recpan').html('month'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','block');
					var dt = new Date($("#from_date").val());
					var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
					var weekmonth =["","First","Second","Third","Fourth","Fifth"];
					var week=dt.getDay();
					var day= dt.getDate();
					
					tot = parseInt(day / 7);
					rem = day % 7;
					
					if(rem!=0){
						tot = tot + 1;
					}
					
					
					if($('#bydayweek').is(':checked')){
						$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text7+' '+weekmonth[tot]+' '+weekdays[week]+' '+eventPluginTextObject.text8+' '+$('#until').val());
					} else {
						$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
					}
					
				break;
				
				case "yearly":
				
					$('#recpan').html('year'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','none');
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text9+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				
				break;
				
			}
		
		
		});
		
		$('#allday_eve').click(function(){
		
			
				if($(this).is(':checked')){
					$('.pm_time_eve').prop('disabled',true);
				}else{
					$('.pm_time_eve').prop('disabled',false);
				}
		
		});
		
		
		$('.daysofweek').click(function(){
			
			var days="";
			$('.daysofweek').each(function(){
			
				if($(this).is(':checked')){
					days+=" "+$(this).val()+",";
				}
			
			});
			
			days = days.slice(0,-1);
			
			
			if($('#freq_event').val()>1){
				var s="s";
				var fre=$('#freq_event').val();
			}else{
				var s="";
				var fre="";
			}
			switch($('#reoc_event').val()){
				case "daily":
				$('#recpan').html('day'+s);
				$('#dayofweekrepeat').css('display','none');
				$('#dayofmonthrepeat').css('display','none');
				$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text19+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				break;
				case "weekly":
				$('#recpan').html('week'+s);
				$('#dayofweekrepeat').css('display','block');
				$('#dayofmonthrepeat').css('display','none');
				$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text20+''+s+' '+eventPluginTextObject.text7+' '+ days +' '+eventPluginTextObject.text8+' '+$('#until').val());
				break;
				case "monthly":
				$('#recpan').html('month'+s);
				$('#dayofweekrepeat').css('display','none');
				$('#dayofmonthrepeat').css('display','block');
				var dt = new Date($("#from_date").val());
				var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
				var weekmonth =["","First","Second","Third","Fourth","Fifth"];
				var week=dt.getDay();
				var day= dt.getDate();
				
				tot=parseInt(day/7);
				rem=day%7;
				
				if(rem!=0){
					tot=tot+1;
				}
				if($('#bydayweek').is(':checked')){
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text7+' '+weekmonth[tot]+' '+weekdays[week]+' '+eventPluginTextObject.text8+' '+$('#until').val());
				}else{
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				}
				break;
				case "yearly":
				$('#recpan').html('year'+s);
				$('#dayofweekrepeat').css('display','none');
				$('#dayofmonthrepeat').css('display','none');
				$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text9+''+s+''+eventPluginTextObject.text8+' '+$('#until').val());
				break;
			}
				
		
		});
		
		
		$('.monthchoose').click(function(){
		
		
		 var dt = new Date($("#from_date").val());
				if($('#freq_event').val()>1){
					var s = "s";
					var fre = $('#freq_event').val();
				} else {
					var s="";
					var fre="";
				}
				var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
				var weekmonth =["","First","Second","Third","Fourth","Fifth"];
				var week=dt.getDay();
				var day= dt.getDate();
				
				tot = parseInt(day/7);
				rem = day%7;
				
				if(rem!=0){
					tot=tot+1;
				}
				
				if($('#reoc_event').val()=='monthly' && $('#bydayweek').is(':checked')){
					$('#recpan').html('month'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','block');
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text7+' '+weekmonth[tot]+' '+weekdays[week]+' '+eventPluginTextObject.text8+' '+$('#until').val());
				
				}
				
				if($('#reoc_event').val()=='monthly' && !$('#bydayweek').is(':checked')){
					$('#recpan').html('month'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','block');
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				
				}
			
			
		
		});
		$('#reoc_event,#freq_event').change(function(){
		
			if($(this).val()!='once'){
				$('.reocurrence_row').css('display','table-row');
			}else{
				$('.reocurrence_row').css('display','none');
			}
			
			if($('#freq_event').val()>1){
				var s="s";
				var fre=$('#freq_event').val();
			}else{
				var s="";
				var fre="";
			}
			switch($('#reoc_event').val()){
				case "daily":
				$('#recpan').html('day'+s);
				$('#dayofweekrepeat').css('display','none');
				$('#dayofmonthrepeat').css('display','none');
				$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text19+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				break;
				case "weekly":
				$('#recpan').html('week'+s);
				$('#dayofweekrepeat').css('display','block');
				$('#dayofmonthrepeat').css('display','none');
				
				var days="";
				$('.daysofweek').each(function(){
				
					if($(this).is(':checked')){
						days += " "+$(this).val()+",";
					}
				
				});
				
				days=days.slice(0,-1);
				
				if(days == ''){
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text20+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				}else{
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text20+''+s+' '+eventPluginTextObject.text7+' '+ days +' '+eventPluginTextObject.text8+' '+$('#until').val());
				}
				
				break;
				case "monthly":
				
				var dt = new Date($("#from_date").val());
				var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
				var weekmonth =["","First","Second","Third","Fourth","Fifth"];
				var week=dt.getDay();
				var day= dt.getDate();
				
				tot=parseInt(day/7);
				rem=day%7;
				
				if(rem!=0){
					tot=tot+1;
				}
				
				
				if($('#bydayweek').is(':checked')){
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text7+' '+weekmonth[tot]+' '+weekdays[week]+' '+eventPluginTextObject.text8+' '+$('#until').val());
				} else {
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				}
				$('#recpan').html('month'+s);
				$('#dayofweekrepeat').css('display','none');
				$('#dayofmonthrepeat').css('display','block');
				
				
				break;
				case "yearly":
				$('#recpan').html('year'+s);
				$('#dayofweekrepeat').css('display','none');
				$('#dayofmonthrepeat').css('display','none');
				$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text9+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				break;
			}
			
		
		});
		
		$("#from_date").datepicker({
			
			'dateFormat':'yy-mm-dd',
			
			onSelect: function (selected) {
				
				var dt = new Date(selected);
				if($('#freq_event').val()>1){
				var s="s";
				var fre=$('#freq_event').val();
					}else{
						var s="";
						var fre="";
					}
				var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
				var weekmonth =["","First","Second","Third","Fourth","Fifth"];
				var week=dt.getDay();
				var day= dt.getDate();
				
				tot = parseInt(day / 7);
				rem = day % 7;
				
				if(rem!=0){
					tot=tot+1;
				}
				
				if($('#reoc_event').val()=='monthly' && $('#bydayweek').is(':checked')){
					$('#recpan').html('month'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','block');
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text7+' '+weekmonth[tot]+' '+weekdays[week]+' '+eventPluginTextObject.text8+' '+$('#until').val());
				
				}
				
				if($('#reoc_event').val()=='monthly' && !$('#bydayweek').is(':checked')){
					$('#recpan').html('month'+s);
					$('#dayofweekrepeat').css('display','none');
					$('#dayofmonthrepeat').css('display','block');
					$('#event_summary').html(eventPluginTextObject.text1 + ' ' + fre+' '+eventPluginTextObject.text6+''+s+' '+eventPluginTextObject.text8+' '+$('#until').val());
				
				}

				
				var $endDate = $('#to_date').val();
				
				if( (dt > new Date($endDate).getTime())) {
				
					$('#pm-events-maxdate-error-top').show();
					$('#pm-events-maxdate-error-top').html('<b>Warning:</b> your start date is greater than your end date. This can cause unexpected results.');
					
				} else if( (dt <= new Date($endDate).getTime()) ) {
					$('#pm-events-maxdate-error-top').hide();
				} else {
					//nothing	
				}

			},
			
		});
		
		
		$("#to_date").datepicker({
			
			'dateFormat':'yy-mm-dd',
			 onSelect: function(selected){
				  
				  var dt = new Date(selected);
				  var $startDate = $('#from_date').val();
				  
				  if( (dt >= new Date($startDate).getTime())) {
				
						$('#pm-events-maxdate-error-top').hide();
						
				  } else if( (dt < new Date($startDate).getTime()) ) {
							
						$('#pm-events-maxdate-error-top').show();
						$('#pm-events-maxdate-error-top').html('<b>Warning:</b> your start date is greater than your end date. This can cause unexpected results.');
							
				  } else {
						//nothing	
				  }
				  
			 }
		   
		});

	
	});
	
})(jQuery);